<?php
session_start();
require_once __DIR__ . '/../config/koneksi.php';

$koneksi = getKoneksi();

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: dashboard.php');
    exit;
}

// Generate CAPTCHA baru jika belum ada
if (!isset($_SESSION['captcha_answer'])) {
    $num1 = rand(1, 15);
    $num2 = rand(1, 10);
    $ops  = ['+', '-', '×'];
    $op   = $ops[array_rand($ops)];
    switch ($op) {
        case '+': $_SESSION['captcha_answer'] = $num1 + $num2; break;
        case '-': 
            if ($num1 < $num2) { $tmp = $num1; $num1 = $num2; $num2 = $tmp; }
            $_SESSION['captcha_answer'] = $num1 - $num2;
            break;
        case '×': 
            $num1 = rand(1,9); $num2 = rand(1,9);
            $_SESSION['captcha_answer'] = $num1 * $num2;
            break;
    }
    $_SESSION['captcha_q'] = "$num1 $op $num2";
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Rate limiting sederhana via session
    if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
    if (!isset($_SESSION['lockout_until']))  $_SESSION['lockout_until']  = 0;

    if (time() < $_SESSION['lockout_until']) {
        $sisa = $_SESSION['lockout_until'] - time();
        $error = "Terlalu banyak percobaan. Coba lagi dalam $sisa detik.";
    } else {
        $username       = trim($_POST['username']  ?? '');
        $password       = $_POST['password']       ?? '';
        $captcha_input  = trim($_POST['captcha']   ?? '');

        // Validasi captcha
        if ((int)$captcha_input !== (int)$_SESSION['captcha_answer']) {
            $error = 'Jawaban verifikasi salah. Silakan coba lagi.';
            // Regenerasi captcha
            unset($_SESSION['captcha_answer'], $_SESSION['captcha_q']);
            $_SESSION['login_attempts']++;
        } elseif (empty($username) || empty($password)) {
            $error = 'Username dan password wajib diisi.';
            unset($_SESSION['captcha_answer'], $_SESSION['captcha_q']);
        } else {
            // ─── Cek credentials ke database ───
            $stmt = mysqli_prepare($koneksi, "SELECT id, username, password_hash, nama_lengkap FROM admin WHERE username = ? AND is_active = 1 LIMIT 1");
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $admin  = mysqli_fetch_assoc($result);

            if ($admin && password_verify($password, $admin['password_hash'])) {
                // Login berhasil
                session_regenerate_id(true);
                $_SESSION['admin_logged_in']  = true;
                $_SESSION['admin_id']         = $admin['id'];
                $_SESSION['admin_username']   = $admin['username'];
                $_SESSION['admin_nama']       = $admin['nama_lengkap'];
                $_SESSION['login_attempts']   = 0;
                unset($_SESSION['captcha_answer'], $_SESSION['captcha_q']);

                // Update last_login
                $upd = mysqli_prepare($koneksi, "UPDATE admin SET last_login = NOW() WHERE id = ?");
                mysqli_stmt_bind_param($upd, 'i', $admin['id']);
                mysqli_stmt_execute($upd);

                header('Location: dashboard.php');
                exit;
            } else {
                $_SESSION['login_attempts']++;
                if ($_SESSION['login_attempts'] >= 5) {
                    $_SESSION['lockout_until']  = time() + 120;
                    $_SESSION['login_attempts'] = 0;
                    $error = 'Terlalu banyak percobaan. Akun dikunci 2 menit.';
                } else {
                    $sisa_coba = 5 - $_SESSION['login_attempts'];
                    $error = "Username atau password salah. Sisa percobaan: $sisa_coba.";
                }
                unset($_SESSION['captcha_answer'], $_SESSION['captcha_q']);
            }
        }
    }

    // Regenerasi captcha jika ada error
    if (!isset($_SESSION['captcha_answer'])) {
        $num1 = rand(1, 15); $num2 = rand(1, 10);
        $ops  = ['+', '-', '×']; $op = $ops[array_rand($ops)];
        switch ($op) {
            case '+': $_SESSION['captcha_answer'] = $num1 + $num2; break;
            case '-':
                if ($num1 < $num2) { $tmp=$num1;$num1=$num2;$num2=$tmp; }
                $_SESSION['captcha_answer'] = $num1 - $num2; break;
            case '×':
                $num1=rand(1,9);$num2=rand(1,9);
                $_SESSION['captcha_answer'] = $num1 * $num2; break;
        }
        $_SESSION['captcha_q'] = "$num1 $op $num2";
    }
}

$captcha_soal = $_SESSION['captcha_q'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Ruang Infor | Login Admin</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet" />
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=DM+Serif+Display&display=swap" rel="stylesheet" />

    <style>
        :root {
            --ri-navy:       #1a3a5c;
            --ri-blue:       #185FA5;
            --ri-blue-mid:   #378ADD;
            --ri-blue-light: #85B7EB;
            --ri-blue-pale:  #E6F1FB;
            --ri-accent:     #F5A623;
            --ri-white:      #ffffff;
            --ri-text:       #1a2533;
            --ri-muted:      #6c7a8d;
            --ri-border:     rgba(26, 58, 92, 0.12);
            --ri-error:      #dc3545;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--ri-text);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background: #f4f7fb;
            position: relative;
            overflow-x: hidden;
        }

        /* ── Dekoratif background ── */
        body::before {
            content: '';
            position: fixed;
            top: -120px;
            right: -120px;
            width: 480px;
            height: 480px;
            background: radial-gradient(circle, rgba(55,138,221,0.12) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
        }
        body::after {
            content: '';
            position: fixed;
            bottom: -100px;
            left: -100px;
            width: 380px;
            height: 380px;
            background: radial-gradient(circle, rgba(26,58,92,0.09) 0%, transparent 70%);
            border-radius: 50%;
            pointer-events: none;
            z-index: 0;
        }

        /* ── TOPBAR ── */
        .ri-topbar {
            background: var(--ri-navy);
            color: rgba(255,255,255,0.75);
            font-size: 12px;
            padding: 6px 0;
            letter-spacing: 0.02em;
            position: relative;
            z-index: 10;
        }
        .ri-topbar a {
            color: rgba(255,255,255,0.75);
            text-decoration: none;
            transition: color .2s;
        }
        .ri-topbar a:hover { color: var(--ri-accent); }

        /* ── MAIN LAYOUT ── */
        .login-wrapper {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 48px 16px;
            position: relative;
            z-index: 1;
        }

        /* ── SPLIT CARD ── */
        .login-card {
            width: 100%;
            max-width: 920px;
            background: var(--ri-white);
            border-radius: 24px;
            box-shadow: 0 20px 60px rgba(24, 95, 165, 0.14);
            overflow: hidden;
            display: flex;
            min-height: 540px;
            animation: fadeUp .5s ease both;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(24px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* ── LEFT PANEL (ilustrasi) ── */
        .login-panel-left {
            width: 42%;
            background: linear-gradient(145deg, var(--ri-navy) 0%, var(--ri-blue) 100%);
            padding: 48px 40px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            position: relative;
            overflow: hidden;
            flex-shrink: 0;
        }

        /* dekorasi geometris di panel kiri */
        .login-panel-left::before {
            content: '';
            position: absolute;
            top: -60px; right: -60px;
            width: 200px; height: 200px;
            border: 2px solid rgba(255,255,255,0.08);
            border-radius: 50%;
        }
        .login-panel-left::after {
            content: '';
            position: absolute;
            bottom: -40px; left: -40px;
            width: 160px; height: 160px;
            border: 2px solid rgba(255,255,255,0.07);
            border-radius: 50%;
        }

        .lp-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            position: relative;
            z-index: 1;
        }
        .lp-logo-icon {
            width: 44px; height: 44px;
            background: rgba(255,255,255,0.15);
            border-radius: 12px;
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 20px;
            backdrop-filter: blur(4px);
            border: 1px solid rgba(255,255,255,0.2);
        }
        .lp-logo-text .brand {
            font-family: 'DM Serif Display', serif;
            font-size: 22px;
            color: white;
            display: block;
            letter-spacing: -0.02em;
        }
        .lp-logo-text .sub {
            font-size: 10px;
            color: rgba(255,255,255,0.6);
            letter-spacing: 0.1em;
            text-transform: uppercase;
            font-weight: 600;
        }

        .lp-content {
            position: relative;
            z-index: 1;
        }
        .lp-content .big-icon {
            width: 80px; height: 80px;
            background: rgba(255,255,255,0.12);
            border-radius: 20px;
            display: flex; align-items: center; justify-content: center;
            font-size: 38px;
            color: white;
            margin-bottom: 24px;
            border: 1px solid rgba(255,255,255,0.18);
        }
        .lp-content h2 {
            font-family: 'DM Serif Display', serif;
            font-size: 26px;
            color: white;
            margin-bottom: 10px;
            line-height: 1.2;
        }
        .lp-content p {
            font-size: 13.5px;
            color: rgba(255,255,255,0.7);
            line-height: 1.7;
        }

        .lp-features {
            position: relative;
            z-index: 1;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .lp-feature-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            color: rgba(255,255,255,0.8);
        }
        .lp-feature-item i {
            width: 28px; height: 28px;
            background: rgba(245,166,35,0.2);
            border-radius: 8px;
            display: flex; align-items: center; justify-content: center;
            color: var(--ri-accent);
            flex-shrink: 0;
            font-size: 14px;
        }

        /* ── RIGHT PANEL (form) ── */
        .login-panel-right {
            flex: 1;
            padding: 48px 44px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .login-title {
            font-size: 22px;
            font-weight: 800;
            color: var(--ri-navy);
            margin-bottom: 4px;
        }
        .login-subtitle {
            font-size: 13.5px;
            color: var(--ri-muted);
            margin-bottom: 32px;
        }

        /* ── FORM FIELDS ── */
        .field-group {
            margin-bottom: 20px;
        }
        .field-group label {
            display: block;
            font-size: 13px;
            font-weight: 700;
            color: var(--ri-navy);
            margin-bottom: 7px;
            letter-spacing: 0.01em;
        }
        .field-wrap {
            position: relative;
        }
        .field-wrap .f-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--ri-blue-light);
            font-size: 16px;
            transition: color .2s;
            pointer-events: none;
        }
        .field-wrap input {
            width: 100%;
            padding: 11px 40px 11px 42px;
            border: 1.5px solid var(--ri-border);
            border-radius: 12px;
            font-size: 14px;
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--ri-text);
            background: #f8fafd;
            outline: none;
            transition: border-color .2s, background .2s, box-shadow .2s;
        }
        .field-wrap input:focus {
            border-color: var(--ri-blue-mid);
            background: white;
            box-shadow: 0 0 0 3.5px rgba(55,138,221,0.13);
        }
        .field-wrap input:focus ~ .f-icon,
        .field-wrap input:focus + .f-icon { color: var(--ri-blue); }
        .field-wrap .toggle-pw {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--ri-muted);
            font-size: 16px;
            cursor: pointer;
            background: none;
            border: none;
            padding: 0;
            line-height: 1;
            transition: color .2s;
        }
        .field-wrap .toggle-pw:hover { color: var(--ri-blue); }

        /* ── CAPTCHA ── */
        .captcha-box {
            background: var(--ri-blue-pale);
            border: 1.5px solid rgba(55,138,221,0.25);
            border-radius: 14px;
            padding: 14px 18px;
            margin-bottom: 22px;
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .captcha-soal {
            background: white;
            border: 1.5px solid rgba(55,138,221,0.2);
            border-radius: 10px;
            padding: 10px 18px;
            font-family: 'DM Serif Display', serif;
            font-size: 22px;
            color: var(--ri-navy);
            letter-spacing: 0.04em;
            flex-shrink: 0;
            white-space: nowrap;
            box-shadow: 0 2px 8px rgba(24,95,165,0.08);
        }
        .captcha-eq {
            font-size: 22px;
            font-weight: 700;
            color: var(--ri-blue);
        }
        .captcha-right {
            flex: 1;
        }
        .captcha-right label {
            font-size: 12px;
            font-weight: 700;
            color: var(--ri-blue);
            letter-spacing: 0.05em;
            text-transform: uppercase;
            display: block;
            margin-bottom: 6px;
        }
        .captcha-right input {
            width: 100%;
            padding: 9px 14px;
            border: 1.5px solid rgba(55,138,221,0.25);
            border-radius: 9px;
            font-size: 15px;
            font-weight: 700;
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: var(--ri-navy);
            background: white;
            outline: none;
            transition: border-color .2s, box-shadow .2s;
            text-align: center;
        }
        .captcha-right input:focus {
            border-color: var(--ri-blue);
            box-shadow: 0 0 0 3px rgba(24,95,165,0.12);
        }

        /* ── ALERT ERROR ── */
        .ri-alert {
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 13.5px;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 22px;
            animation: shake .4s ease;
        }
        .ri-alert-error {
            background: #fff0f0;
            border: 1.5px solid #f5c6c6;
            color: #8b1a1a;
        }
        .ri-alert-success {
            background: #eafaf1;
            border: 1.5px solid #a3d9b8;
            color: #155724;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%       { transform: translateX(-6px); }
            40%       { transform: translateX(6px); }
            60%       { transform: translateX(-4px); }
            80%       { transform: translateX(4px); }
        }

        /* ── BTN LOGIN ── */
        .btn-login {
            width: 100%;
            padding: 13px;
            background: linear-gradient(135deg, var(--ri-blue), var(--ri-navy));
            color: white;
            font-size: 15px;
            font-weight: 700;
            font-family: 'Plus Jakarta Sans', sans-serif;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            letter-spacing: 0.01em;
            transition: transform .2s, box-shadow .2s, opacity .2s;
            box-shadow: 0 6px 20px rgba(24, 95, 165, 0.32);
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 28px rgba(24, 95, 165, 0.40);
        }
        .btn-login:active {
            transform: translateY(0);
            box-shadow: 0 4px 12px rgba(24, 95, 165, 0.28);
        }
        .btn-login:disabled {
            opacity: .6;
            cursor: not-allowed;
            transform: none;
        }

        .back-link {
            text-align: center;
            margin-top: 22px;
            font-size: 13px;
            color: var(--ri-muted);
        }
        .back-link a {
            color: var(--ri-blue);
            font-weight: 600;
            text-decoration: none;
            transition: color .2s;
        }
        .back-link a:hover { color: var(--ri-navy); }

        /* ── FOOTER ── */
        .ri-footer-mini {
            text-align: center;
            padding: 20px 16px;
            font-size: 12px;
            color: var(--ri-muted);
            position: relative;
            z-index: 1;
        }

        /* ── LOADING SPINNER ── */
        .spinner {
            width: 18px; height: 18px;
            border: 2.5px solid rgba(255,255,255,0.4);
            border-top-color: white;
            border-radius: 50%;
            animation: spin .7s linear infinite;
            display: none;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* ── RESPONSIVE ── */
        @media (max-width: 768px) {
            .login-card { flex-direction: column; max-width: 480px; }
            .login-panel-left { width: 100%; padding: 32px 28px; min-height: unset; }
            .lp-content h2 { font-size: 20px; }
            .lp-features { flex-direction: row; flex-wrap: wrap; gap: 8px; }
            .lp-feature-item { font-size: 12px; }
            .login-panel-right { padding: 32px 28px; }
        }
        @media (max-width: 480px) {
            .login-panel-left { padding: 24px 20px; }
            .login-panel-right { padding: 24px 20px; }
            .captcha-box { flex-direction: column; gap: 10px; }
            .captcha-soal { font-size: 20px; }
        }
    </style>
</head>
<body>

    <!-- TOPBAR -->
    <div class="ri-topbar">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-mortarboard-fill" style="color:var(--ri-accent);font-size:12px;"></i>
                <span>Portal Materi Jurusan Informatika</span>
            </div>
            <div>
                <i class="bi bi-shield-lock me-1"></i>
                <span>Panel Administrator</span>
            </div>
        </div>
    </div>

    <!-- MAIN -->
    <div class="login-wrapper">
        <div class="login-card">

            <!-- ── PANEL KIRI ── -->
            <div class="login-panel-left">
                <a href="../index.php" class="lp-logo">
                    <div class="lp-logo-icon">
                        <i class="bi bi-journal-code"></i>
                    </div>
                    <div class="lp-logo-text">
                        <span class="brand">Ruang Infor</span>
                        <span class="sub">Informatika S1</span>
                    </div>
                </a>

                <div class="lp-content">
                    <div class="big-icon">
                        <i class="bi bi-shield-lock"></i>
                    </div>
                    <h2>Area Khusus Admin</h2>
                    <p>Kelola konten, materi, dan data mahasiswa melalui panel administrasi Ruang Infor yang aman dan terpercaya.</p>
                </div>

                <div class="lp-features">
                    <div class="lp-feature-item">
                        <i class="bi bi-check2-circle d-flex align-items-center justify-content-center"></i>
                        Kelola materi & mata kuliah
                    </div>
                    <div class="lp-feature-item">
                        <i class="bi bi-check2-circle d-flex align-items-center justify-content-center"></i>
                        Manajemen pengguna & semester
                    </div>
                    <div class="lp-feature-item">
                        <i class="bi bi-check2-circle d-flex align-items-center justify-content-center"></i>
                        Akses terenkripsi & aman
                    </div>
                </div>
            </div>

            <!-- ── PANEL KANAN ── -->
            <div class="login-panel-right">
                <div class="login-title">Selamat Datang 👋</div>
                <div class="login-subtitle">Masuk ke panel admin Ruang Infor</div>

                <?php if ($error): ?>
                    <div class="ri-alert ri-alert-error" role="alert">
                        <i class="bi bi-exclamation-triangle-fill" style="flex-shrink:0;font-size:16px;"></i>
                        <span><?= htmlspecialchars($error) ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" novalidate id="loginForm">

                    <!-- Username -->
                    <div class="field-group">
                        <label for="username">Username</label>
                        <div class="field-wrap">
                            <input
                                type="text"
                                id="username"
                                name="username"
                                placeholder="Masukkan username admin"
                                value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                                autocomplete="username"
                                required
                            />
                            <i class="bi bi-person f-icon"></i>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="field-group">
                        <label for="password">Password</label>
                        <div class="field-wrap">
                            <input
                                type="password"
                                id="password"
                                name="password"
                                placeholder="Masukkan password"
                                autocomplete="current-password"
                                required
                            />
                            <i class="bi bi-lock f-icon"></i>
                            <button type="button" class="toggle-pw" id="togglePw" aria-label="Tampilkan/sembunyikan password">
                                <i class="bi bi-eye" id="eyeIcon"></i>
                            </button>
                        </div>
                    </div>

                    <!-- CAPTCHA -->
                    <div class="captcha-box" role="group" aria-labelledby="captcha-label">
                        <div class="captcha-soal" id="captcha-soal" aria-label="Soal matematika">
                            <?= htmlspecialchars($captcha_soal) ?>
                        </div>
                        <div class="captcha-eq">=</div>
                        <div class="captcha-right">
                            <label for="captcha" id="captcha-label">
                                <i class="bi bi-shield-check me-1"></i>Verifikasi Keamanan
                            </label>
                            <input
                                type="number"
                                id="captcha"
                                name="captcha"
                                placeholder="?"
                                min="-999"
                                max="999"
                                autocomplete="off"
                                required
                                aria-describedby="captcha-label"
                            />
                        </div>
                    </div>

                    <!-- Submit -->
                    <button type="submit" class="btn-login" id="btnLogin">
                        <span id="btnText"><i class="bi bi-box-arrow-in-right"></i> Masuk ke Panel Admin</span>
                        <div class="spinner" id="btnSpinner"></div>
                    </button>

                </form>

                <div class="back-link">
                    <i class="bi bi-arrow-left me-1"></i>
                    <a href="../index.php">Kembali ke Beranda</a>
                </div>
            </div>

        </div><!-- /.login-card -->
    </div><!-- /.login-wrapper -->

    <!-- FOOTER MINI -->
    <div class="ri-footer-mini">
        &copy; <?= date('Y') ?> <strong style="color:var(--ri-navy);">Ruang Infor</strong> &mdash; Jurusan Informatika S1
    </div>

    <script>
    // Toggle show/hide password
    const togglePw = document.getElementById('togglePw');
    const pwInput  = document.getElementById('password');
    const eyeIcon  = document.getElementById('eyeIcon');

    togglePw.addEventListener('click', function () {
        const isHidden = pwInput.type === 'password';
        pwInput.type   = isHidden ? 'text' : 'password';
        eyeIcon.className = isHidden ? 'bi bi-eye-slash' : 'bi bi-eye';
    });

    // Loading state saat submit
    document.getElementById('loginForm').addEventListener('submit', function () {
        const btn     = document.getElementById('btnLogin');
        const text    = document.getElementById('btnText');
        const spinner = document.getElementById('btnSpinner');
        btn.disabled       = true;
        text.style.display = 'none';
        spinner.style.display = 'block';
    });

    // Focus username otomatis
    document.addEventListener('DOMContentLoaded', function () {
        const un = document.getElementById('username');
        if (un && !un.value) un.focus();
        else document.getElementById('captcha').focus();
    });
    </script>

</body>
</html>