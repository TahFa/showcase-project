<?php
function getKoneksi(): mysqli {
    $koneksi = mysqli_connect("localhost", "root", "", "db_ruang_infor");

    if (!$koneksi) {
        die("Koneksi gagal: " . mysqli_connect_error());
    }

    return $koneksi;
}