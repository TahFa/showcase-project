<?php
include 'admin/koneksi.php';
$produk = mysqli_query($conn, "SELECT * FROM produk ORDER BY id DESC LIMIT 6");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>UMKM Batik Nusantara</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f8f5f0;
        }

        /* NAVBAR BATIK */
        .navbar {
            background: linear-gradient(90deg, #5a3e2b, #8b5e3c);
        }

        /* HERO */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),
                url('https://images.unsplash.com/photo-1596464716127-f2a82984de30');
            background-size: cover;
            background-position: center;
            min-height: 90vh;
            color: white;
            display: flex;
            align-items: center;
        }

        /* CARD PRODUK */
        .product-card {
            transition: 0.3s;
            border-radius: 12px;
            overflow: hidden;
        }

        .product-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .card-img-top {
            height: 220px;
            object-fit: cover;
        }

        .harga {
            color: #8b5e3c;
            font-weight: bold;
        }

        footer {
            background: #5a3e2b;
            color: white;
        }
    </style>

</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark shadow fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="#">
                <i class="bi bi-flower1"></i> Batik Nusantara
            </a>

            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="menu">
                <ul class="navbar-nav ms-auto">

                    <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="#produk">Produk</a></li>
                    <li class="nav-item"><a class="nav-link" href="#tentang">Tentang</a></li>
                    <li class="nav-item"><a class="nav-link" href="#kontak">Kontak</a></li>

                    <li class="nav-item ms-3">
                        <a class="btn btn-warning" href="staff/login.php">
                            <i class="bi bi-person-circle"></i> Login
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>


    <!-- HERO -->
    <section class="hero mt-5" id="home">
        <div class="container text-center">
            <h1 class="display-4 fw-bold">UMKM Batik Nusantara</h1>
            <p class="lead">Produk batik berkualitas dengan sentuhan budaya Indonesia</p>
            <a href="#produk" class="btn btn-warning btn-lg mt-3">Lihat Produk</a>
        </div>
    </section>


    <!-- PRODUK -->
    <section class="py-5" id="produk">
        <div class="container">

            <h2 class="text-center mb-5">Produk Batik</h2>

            <div class="row g-4">

                <?php if (mysqli_num_rows($produk) > 0): ?>
                    <?php while ($p = mysqli_fetch_assoc($produk)): ?>

                        <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                            <div class="card product-card h-100">

                                <img src="admin/img/<?= $p['gambar'] ?>" class="card-img-top">

                                <div class="card-body d-flex flex-column">

                                    <h6 class="card-title"><?= $p['nama_produk'] ?></h6>

                                    <p class="harga mb-2">
                                        Rp <?= number_format($p['harga']) ?>
                                    </p>

                                    <span class="badge bg-success mb-3">
                                        Stok: <?= $p['stok'] ?>
                                    </span>

                                    <a href="#" class="btn btn-outline-primary mt-auto">
                                        Beli
                                    </a>

                                </div>

                            </div>
                        </div>

                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-center">Belum ada produk</p>
                <?php endif; ?>

            </div>
        </div>
    </section>


    <!-- TENTANG -->
    <section class="bg-light py-5" id="tentang">
        <div class="container text-center">
            <h2 class="mb-4">Tentang UMKM</h2>
            <p class="lead">
                UMKM Batik Nusantara menghadirkan batik berkualitas dengan sentuhan budaya Indonesia.
            </p>
        </div>
    </section>


    <!-- KONTAK -->
    <section class="py-5" id="kontak">
        <div class="container">
            <h2 class="text-center mb-4">Kontak</h2>

            <div class="row justify-content-center">
                <div class="col-md-6">

                    <form>
                        <input type="text" class="form-control mb-3" placeholder="Nama">
                        <input type="email" class="form-control mb-3" placeholder="Email">
                        <textarea class="form-control mb-3" rows="4" placeholder="Pesan"></textarea>
                        <button class="btn btn-dark w-100">Kirim Pesan</button>
                    </form>

                </div>
            </div>
        </div>
    </section>


    <!-- FOOTER -->
    <footer class="py-4 text-center">
        <p>© 2026 UMKM Batik Nusantara</p>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>