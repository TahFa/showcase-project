<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {

    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    move_uploaded_file($tmp, "img/" . $gambar);

    mysqli_query($conn, "INSERT INTO produk(nama_produk, harga, stok, gambar) VALUES (
        '$nama',
        '$harga',
        '$stok',
        '$gambar'
    )");

    header("location:index.php?menu=produk");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tambah Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-4">

        <h3>Tambah Produk</h3>

        <form method="POST" enctype="multipart/form-data">

            <div class="mb-3">
                <label>Nama Produk</label>
                <input type="text" name="nama" class="form-control" required>
            </div>
          
            <div class="mb-3">
                <label>Harga</label>
                <input type="number" name="harga" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Stok</label>
                <input type="number" name="stok" class="form-control"></input>
            </div>

            <div class="mb-3">
                <label>Gambar</label>
                <input type="file" name="gambar" class="form-control" required>
            </div>

            <button class="btn btn-success" name="submit">Simpan</button>
            <a href="index.php?menu=produk" class="btn btn-secondary">Kembali</a>

        </form>

    </div>

</body>

</html>