    <div class="content container mt-4">

        <h3 class="mb-3">Dashboard Admin</h3>
        <p class="welcome-text">Selamat datang, <?= $_SESSION['nama']; ?></p>

        <div class="row mt-4">

            <!-- CARD PRODUK -->
            <div class="col-md-4 mb-3">
                <div class="card card-dashboard p-3">
                    <h5>Total Produk</h5>
                    <h3><?php include "total_produk.php"; ?></h3>
                    <small class="text-muted">Data produk saat ini</small>
                </div>
            </div>

            <!-- CARD STAF -->
            <div class="col-md-4 mb-3">
                <div class="card card-dashboard p-3">
                    <h5>Total Staf</h5>
                    <h3><?php include "total_staf.php"; ?></h3>
                    <small class="text-muted">Jumlah staf aktif</small>
                </div>
            </div>

            <!-- CARD LAPORAN -->
            <div class="col-md-4 mb-3">
                <div class="card card-dashboard p-3">
                    <h5>Laporan Hari Ini</h5>
                    <h3>Rp 2.5jt</h3>
                    <small class="text-muted">Pendapatan hari ini</small>
                </div>
            </div>

        </div>

    </div>