<?php
include 'koneksi.php';

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM users WHERE id='$id'");
$d = mysqli_fetch_assoc($data);

if (isset($_POST['submit'])) {

    $username = $_POST['username'];
    $nama = $_POST['nama'];
    $role = $_POST['role'];

    if ($_POST['password'] != "") {
        $password = md5($_POST['password']);

        mysqli_query($conn, "UPDATE users SET
            username='$username',
            password='$password',
            nama='$nama',
            role='$role'
            WHERE id='$id'
        ");
    } else {
        mysqli_query($conn, "UPDATE users SET
            username='$username',
            nama='$nama',
            role='$role'
            WHERE id='$id'
        ");
    }

    header("location: index.php?menu=staf");
}
?>

<h3>Edit Staf</h3>

<form method="POST">

    <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" value="<?= $d['username'] ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Password (kosongkan jika tidak diubah)</label>
        <input type="password" name="password" class="form-control">
    </div>

    <div class="mb-3">
        <label>Nama</label>
        <input type="text" name="nama" value="<?= $d['nama'] ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Role</label>
        <select name="role" class="form-control">
            <option value="admin" <?= $d['role']=='admin'?'selected':'' ?>>Admin</option>
            <option value="staf" <?= $d['role']=='staf'?'selected':'' ?>>Staf</option>
            <option value="staf" <?= $d['role']=='pemilik'?'selected':'' ?>>Owner</option>
        </select>
    </div>

    <button class="btn btn-success" name="submit">Update</button>
    <a href="index.php?menu=staf" class="btn btn-secondary">Kembali</a>

</form>