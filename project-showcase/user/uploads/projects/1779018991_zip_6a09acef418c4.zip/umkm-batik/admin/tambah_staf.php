<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {

    $username = $_POST['username'];
    $password = md5($_POST['password']); // simple dulu
    $nama = $_POST['nama'];
    $role = $_POST['role'];

    mysqli_query($conn, "INSERT INTO users VALUES (
        '',
        '$username',
        '$password',
        '$nama',
        '$role',
        NOW()
    )");

    header("location:index.php?menu=staf");
}
?>

<h3>Tambah Staf</h3>

<form method="POST">

    <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Nama</label>
        <input type="text" name="nama" class="form-control">
    </div>

    <div class="mb-3">
        <label>Role</label>
        <select name="role" class="form-control">
            <option value="admin">Admin</option>
            <option value="staf">Staf</option>
            <option value="pemilik">Owner</option>
        </select>
    </div>

    <button class="btn btn-success" name="submit">Simpan</button>
    <a href="index.php?menu=staf" class="btn btn-secondary">Kembali</a>

</form>