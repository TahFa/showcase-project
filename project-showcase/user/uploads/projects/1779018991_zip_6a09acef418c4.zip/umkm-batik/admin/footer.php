</div> <!-- end content -->

<footer class="footer-custom">
    © <?= date('Y') ?> UMKM Batik | Dibuat oleh <span><?= "Guwejh"; ?></span>
</footer>

</div> <!-- end wrapper -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>