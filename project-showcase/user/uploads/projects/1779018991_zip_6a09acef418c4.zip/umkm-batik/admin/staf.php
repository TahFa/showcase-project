<?php
include 'koneksi.php';
$data = mysqli_query($conn, "SELECT * FROM users");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Data Staf</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f5f0;
        }

        /* CARD STYLE */
        .card-custom {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        /* HEADER KHUSUS STAF (HIJAU BATIK) */
        .card-header-custom {
            background: linear-gradient(90deg, #3e5c4a, #6b8f71);
            color: white;
            font-weight: 500;
            padding: 12px 20px;
            border-bottom: 3px solid #d4af37;
            /* aksen emas */
        }

        /* TABLE MENYATU */
        table.dataTable {
            margin-top: 0 !important;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead {
            background: linear-gradient(90deg, #3e5c4a, #6b8f71);
            color: #fff;
        }

        .table tbody tr:hover {
            background-color: #f0f5f2;
        }

        /* DATATABLE */
        .dataTables_wrapper .dataTables_filter input {
            border-radius: 8px;
            padding: 5px 10px;
        }

        .dataTables_wrapper .dataTables_length select {
            border-radius: 8px;
        }
    </style>
</head>

<body>

    <div class="container mt-4">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Data Staf</h3>
            <a href="?menu=tambah_staf" class="btn btn-success" style="font-weight:500">+ Tambah Staf</a>
        </div>

        <div class="card card-custom">

            <div class="card-header-custom">
                Daftar Staf
            </div>

            <div class="card-body">

                <table id="tabelStaf" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Nama</th>
                            <th>Role</th>
                            <th>Dibuat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($data)) { ?>
                            <tr>
                                <td><?= $no++ ?></td>

                                <td><?= $row['username'] ?></td>

                                <td><?= $row['nama'] ?></td>

                                <td>
                                    <?php
                                    $roleColor = ($row['role'] == 'admin') ? 'bg-warning' : 'bg-info';
                                    ?>
                                    <span class="badge <?= $roleColor ?>">
                                        <?= $row['role'] ?>
                                    </span>
                                </td>

                                <td><?= $row['created_at'] ?></td>

                                <td>
                                    <a href="?menu=edit_staf&id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="hapus_staf.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>

            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#tabelStaf').DataTable({
                "pageLength": 5,
                "lengthMenu": [5, 10, 25, 50],
                "language": {
                    "search": "Cari:",
                    "lengthMenu": "Tampilkan _MENU_ data",
                    "info": "Menampilkan _START_ - _END_ dari _TOTAL_ data",
                    "paginate": {
                        "next": "Next",
                        "previous": "Prev"
                    }
                }
            });
        });
    </script>

</body>

</html>