
<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
        body {
            height: 100vh;
            background: linear-gradient(135deg, #4e73df, #1cc88a);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-card {
            width: 380px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .captcha-img {
            border-radius: 5px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }
    </style>

</head>

<body>

    <div class="card login-card p-4">

        <h3 class="text-center mb-4">Login Admin</h3>

        <form method="POST" action="proses_login.php">

            <div class="mb-3">

                <label class="form-label">Username</label>

                <div class="input-group">
                    <span class="input-group-text">
                        <i class="fa fa-user"></i>
                    </span>

                    <input type="text" name="username" class="form-control" required>

                </div>
            </div>


            <div class="mb-3">

                <label class="form-label">Password</label>

                <div class="input-group">
                    <span class="input-group-text">
                        <i class="fa fa-lock"></i>
                    </span>

                    <input type="password" name="password" class="form-control" required>

                </div>
            </div>


            <div class="mb-3">

                <label class="form-label">Captcha</label>

                <br>

                <img src="captcha.php?rand=<?php echo rand(); ?>" id="captcha" class="captcha-img">

                <button type="button" onclick="refreshCaptcha()" class="btn btn-sm btn-outline-secondary ms-2">
                    <i class="fa fa-rotate"></i>
                </button>

                <input type="text" name="captcha" class="form-control mt-2" placeholder="Masukkan captcha" required>

            </div>

            <button class="btn btn-primary w-100">
                Login
            </button>

        </form>

    </div>

    <script>
        function refreshCaptcha() {
            document.getElementById("captcha").src = "captcha.php?rand=" + Math.random();
        }
    </script>

</body>

</html>