<?php
include 'koneksi.php';

$id = $_GET['id'];

$data = mysqli_query($conn, "SELECT gambar FROM produk WHERE id='$id'");
$d = mysqli_fetch_assoc($data);

unlink("img/" . $d['gambar']);

mysqli_query($conn, "DELETE FROM produk WHERE id='$id'");

header("location:index.php?menu=produk");
