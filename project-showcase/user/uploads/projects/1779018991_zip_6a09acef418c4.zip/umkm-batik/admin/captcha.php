<?php
session_start();

$karakter = 'ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghjkimnopqrstuvwxyz';
$captcha = '';

for ($i = 0; $i < 4; $i++) {
    $captcha .= $karakter[rand(0, strlen($karakter) - 1)];
}

$_SESSION['captcha'] = $captcha;

$img = imagecreate(120, 40);
$bg = imagecolorallocate($img, 240, 240, 240);
$textcolor = imagecolorallocate($img, 0, 0, 0);

imagestring($img, 5, 35, 10, $captcha, $textcolor);

header("Content-type: image/png");
imagepng($img);
imagedestroy($img);
?>