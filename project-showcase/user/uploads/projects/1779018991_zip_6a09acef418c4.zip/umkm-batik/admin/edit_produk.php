<?php
include 'koneksi.php';

$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM produk WHERE id='$id'");
$d = mysqli_fetch_assoc($data);

if (isset($_POST['submit'])) {

    $nama = $_POST['nama'];
    $stok = $_POST['stok'];
    $harga = $_POST['harga'];

    if ($_FILES['gambar']['name'] != "") {
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];

        move_uploaded_file($tmp, "img/" . $gambar);

        mysqli_query($conn, "UPDATE produk SET
            nama_produk='$nama',
            stok='$stok',
            harga='$harga',
            gambar='$gambar'
            WHERE id='$id'
        ");
    } else {
        mysqli_query($conn, "UPDATE produk SET
            nama_produk='$nama',
            stok='$stok',
            harga='$harga'
            WHERE id='$id'
        ");
    }

    header("location:index.php?menu=produk");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-4 mb-5">

        <h3>Edit Produk</h3>

        <form method="POST" enctype="multipart/form-data">

            <div class="mb-3">
                <label>Nama Produk</label>
                <input type="text" name="nama" value="<?= $d['nama_produk'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Harga</label>
                <input type="number" name="harga" value="<?= $d['harga'] ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Stok</label>
                <textarea name="stok" class="form-control"><?= $d['stok'] ?></textarea>
            </div>

            <div class="mb-3">
                <label>Gambar</label><br>
                <img src="img/<?= $d['gambar'] ?>" width="100"><br><br>
                <input type="file" name="gambar" class="form-control">
            </div>

            <button class="btn btn-success" name="submit">Update</button>
            <a href="index.php?menu=produk" class="btn btn-secondary">Kembali</a>

        </form>

    </div>

</body>

</html>