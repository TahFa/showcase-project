<?php
include 'koneksi.php';
$query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM users");
$data  = mysqli_fetch_assoc($query);

$total_produk = $data['total'];

echo $total_produk;
?>