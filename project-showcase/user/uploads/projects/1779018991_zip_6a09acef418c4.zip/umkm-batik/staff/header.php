<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Staff Panel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        html,
        body {
            height: 100%;
        }

        /* NAVBAR BATIK */
        .navbar-custom {
            background: linear-gradient(90deg, #5a3e2b, #8b5e3c);
        }

        .navbar-custom .nav-link,
        .navbar-custom .navbar-brand {
            color: #fdf6e3;
            font-weight: 500;
        }

        .navbar-custom .navbar-brand:hover,
        .navbar-custom .nav-link:hover {
            color: #ffd700;
            /* emas */
        }

        .wrapper {
            min-height: 100%;
            display: flex;
            flex-direction: column;
        }

        .content {
            flex: 1;
        }

        .footer-custom {
            background: #5a3e2b;
            color: #fdf6e3;
            text-align: center;
            padding: 15px;
            border-top: 3px solid #c19a6b;
        }
    </style>
</head>

<body>

    <div class="wrapper">

        <!-- NAVBAR -->
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container">
                <a class="navbar-brand" href="index.php">Staff Panel</a>

                <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    ☰
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">

                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Dashboard</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?menu=produk">Produk</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="index.php?menu=transaksi_masuk">Transaksi Barang Masuk</a>
                        </li>

                        <!-- DROPDOWN LAPORAN -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                Laporan
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="?menu=laporan_pembelian">Laporan Pembelian</a></li>
                                <li><a class="dropdown-item" href="?menu=laporan_penjualan">Laporan Penjualan</a></li>
                                <li><a class="dropdown-item" href="?menu=laporan_produk">Laporan Produk</a></li>
                            </ul>
                        </li>

                        <li class="nav-item">
                            <a class="btn btn-outline-danger" href="logout.php" style="font-weight: 500;">Logout</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>

        <div class="content container mt-4">
