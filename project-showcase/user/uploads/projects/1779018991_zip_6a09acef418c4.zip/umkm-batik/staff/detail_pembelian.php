<?php
include 'koneksi.php';

$id = $_GET['id'];

$data = mysqli_query($conn, "
    SELECT p.nama_produk, dp.jumlah
    FROM detail_produk_masuk dp
    JOIN produk p ON dp.produk_id = p.id
    WHERE dp.produk_id = '$id'
");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Detail Transaksi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-4">

        <h4>Detail Transaksi #TRX-<?= $id ?></h4>

        <table class="table table-bordered">
            <tr>
                <th>Produk</th>
                <th>Jumlah</th>
            </tr>

            <?php while ($d = mysqli_fetch_assoc($data)) { ?>
                <tr>
                    <td><?= $d['nama_produk'] ?></td>
                    <td><?= $d['jumlah'] ?></td>
                </tr>
            <?php } ?>

        </table>

        <a href="index.php?menu=laporan_pembelian" class="btn btn-secondary">Kembali</a>

    </div>

</body>

</html>