<?php
include 'koneksi.php';
$data = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Data Produk</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f5f0;
        }

        /* CARD STYLE */
        .card-custom {
            border: none;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .card-header-custom {
            background: #8b5e3c;
            color: white;
            font-weight: 500;
            padding: 12px 20px;
            border-bottom: 3px solid #d4af37;
        }

        /* TABLE MENYATU */
        table.dataTable {
            margin-top: 0 !important;
        }

        .table {
            margin-bottom: 0;
        }

        .table thead {
            background-color: #5a3e2b;
            color: #fff;
        }

        .table tbody tr:hover {
            background-color: #f2e9e1;
        }

        /* DATATABLE WRAPPER */
        .dataTables_wrapper .dataTables_filter input {
            border-radius: 8px;
            padding: 5px 10px;
        }

        .dataTables_wrapper .dataTables_length select {
            border-radius: 8px;
        }
    </style>
</head>

<body>

    <div class="container mt-4 mb-5">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3>Data Produk</h3>
            <a href="?menu=tambah_produk" class="btn btn-primary" style="color: white; font-weight:500;">+ Tambah Produk</a>

        </div>

        <div class="card card-custom">

            <div class="card-header-custom">
                Daftar Produk Batik
            </div>

            <div class="card-body">

                <table id="tabelProduk" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Gambar</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($data)) { ?>
                            <tr>
                                <td><?= $no++ ?></td>

                                <td>
                                    <img src="../admin/img/<?= $row['gambar'] ?>" width="70" class="rounded">
                                </td>

                                <td><?= $row['nama_produk'] ?></td>

                                <td>Rp <?= number_format($row['harga']) ?></td>

                                <td>
                                    <?php
                                    $warna = ($row['stok'] > 10) ? 'bg-success' : (($row['stok'] > 0) ? 'bg-warning' : 'bg-danger');
                                    ?>
                                    <span class="badge <?= $warna ?>"><?= $row['stok'] ?></span>
                                </td>

                                <td>
                                    <a href="?menu=edit_produk&id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="hapus_produk.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>

                </table>

            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#tabelProduk').DataTable({
                "pageLength": 5,
                "lengthMenu": [5, 10, 25, 50],
                "language": {
                    "search": "Cari:",
                    "lengthMenu": "Tampilkan _MENU_ data",
                    "info": "Menampilkan _START_ - _END_ dari _TOTAL_ data",
                    "paginate": {
                        "next": "Next",
                        "previous": "Prev"
                    }
                }
            });
        });
    </script>

</body>

</html>