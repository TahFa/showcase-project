<?php
include 'koneksi.php';

$produk = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html>

<head>
    <title>Transaksi Masuk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f5f0;
        }

        .card-custom {
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        /* BATIK HIJAU */
        .header-batik {
            background: linear-gradient(90deg, #3e5c4a, #6b8f71);
            color: white;
            padding: 12px;
            border-bottom: 3px solid #d4af37;
        }

        .btn-batik {
            background: #3e5c4a;
            color: white;
        }

        .btn-batik:hover {
            background: #2f4638;
            color: azure;
        }
    </style>
</head>

<body>

    <div class="container mt-4">

        <h3 class="mb-4">Transaksi Produk Masuk</h3>

        <!-- FORM TAMBAH PRODUK -->
        <div class="card card-custom mb-4">
            <div class="header-batik">Tambah Produk</div>

            <div class="card-body">
                <form method="POST" action="tambah_keranjang.php">

                    <div class="row">
                        <div class="col-md-6 mb-2">
                            <select name="produk_id" class="form-control">
                                <?php while ($p = mysqli_fetch_assoc($produk)) { ?>
                                    <option value="<?= $p['id'] ?>">
                                        <?= $p['nama_produk'] ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-3 mb-2">
                            <input type="number" name="jumlah" class="form-control" placeholder="jumlah" required>
                        </div>

                        <div class="col-md-3 mb-2">
                            <button class="btn btn-batik w-100">+ Tambah</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>

        <!-- TABEL KERANJANG -->
        <div class="card card-custom mb-5">
            <div class="header-batik">Keranjang</div>

            <div class="card-body">

                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Produk</th>
                            <th>Jumlah</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php
                        $no = 1;
                        if (!empty($_SESSION['keranjang'])) {
                            foreach ($_SESSION['keranjang'] as $id => $qty) {

                                $p = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM produk WHERE id='$id'"));
                        ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td><?= $p['nama_produk'] ?></td>
                                    <td><?= $qty ?></td>
                                    <td>
                                        <a href="hapus_keranjang.php?id=<?= $id ?>"
                                            class="btn btn-outline-danger btn-sm"
                                            onclick="return confirm('Hapus dari keranjang?')">
                                            Hapus
                                        </a>
                                    </td>
                                </tr>
                        <?php }
                        } ?>
                    </tbody>

                </table>

                <div class="mt-3">
                    <a href="simpan_transaksi.php" class="btn btn-success">
                        Simpan Transaksi
                    </a>
                </div>

            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>