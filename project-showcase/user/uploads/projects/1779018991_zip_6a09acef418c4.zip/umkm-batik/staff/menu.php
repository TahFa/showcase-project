<?php
if (isset($_GET['menu'])) {
    $menu = $_GET['menu'];
} else {
    $menu = "";
}
if ($menu == "produk") {
    include "produk.php";
} else if ($menu == "edit_produk") {
    include "edit_produk.php";
} else if ($menu == "tambah_produk") {
    include "tambah_produk.php";
} else if ($menu == "transaksi_masuk") {
    include "transaksi_masuk.php";
} else if ($menu == "laporan_pembelian") {
    include "laporan_pembelian.php";
} else if ($menu == "detail_pembelian") {
    include "detail_pembelian.php";
} else {
    include "home.php";
}
