<?php
session_start();

if ($_SESSION['role'] != 'staf') {
    echo "<script>
        alert('Akses ditolak! Bukan staf');
        window.location='../admin/index.php';
    </script>";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Staff Panel</title>
</head>

<body>

    <?php
    if (!isset($_SESSION['login'])) {
        include 'login.php';
    } else {
        include 'dashboard.php';
    }
    ?>
</body>

</html>