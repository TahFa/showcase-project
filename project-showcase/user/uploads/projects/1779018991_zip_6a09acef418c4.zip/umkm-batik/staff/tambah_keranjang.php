<?php
session_start();

$id = $_POST['produk_id'];
$jumlah = $_POST['jumlah'];

if (isset($_SESSION['keranjang'][$id])) {
    $_SESSION['keranjang'][$id] += $jumlah;
} else {
    $_SESSION['keranjang'][$id] = $jumlah;
}

header("location:index.php?menu=transaksi_masuk");
