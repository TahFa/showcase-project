<?php
session_start();
include 'koneksi.php';

$user_id = $_SESSION['id'];

// simpan transaksi
mysqli_query($conn, "INSERT INTO produk_masuk (user_id) VALUES ('$user_id')");
$transaksi_id = mysqli_insert_id($conn);

// loop keranjang
foreach ($_SESSION['keranjang'] as $produk_id => $jumlah) {

    // simpan detail
    mysqli_query($conn, "INSERT INTO detail_produk_masuk 
        (produkMasuk_id, produk_id, jumlah)
        VALUES ('$transaksi_id', '$produk_id', '$jumlah')
    ");

    // 🔥 UPDATE STOK
    mysqli_query($conn, "UPDATE produk 
        SET stok = stok + $jumlah 
        WHERE id='$produk_id'
    ");
}

// kosongkan keranjang
unset($_SESSION['keranjang']);

header("location:index.php?menu=transaksi_masuk");