<?php
include 'koneksi.php';

$tgl_awal = $_GET['tgl_awal'] ?? '';
$tgl_akhir = $_GET['tgl_akhir'] ?? '';

$where = "";

if ($tgl_awal && $tgl_akhir) {
    $where = "WHERE DATE(tanggal) BETWEEN '$tgl_awal' AND '$tgl_akhir'";
}

$query = mysqli_query($conn, "
    SELECT 
        pm.id,
        pm.tanggal,
        u.nama,
        SUM(dp.jumlah) as total_item
    FROM produk_masuk pm
    JOIN users u ON pm.user_id = u.id
    JOIN detail_produk_masuk dp ON pm.id = dp.produkMasuk_id
    $where
    GROUP BY pm.id
    ORDER BY pm.id DESC
");

$data_chart = mysqli_query($conn, "
    SELECT DATE(tanggal) as tgl, COUNT(*) as total
    FROM produk_masuk
    $where
    GROUP BY DATE(tanggal)
");

$labels = [];
$values = [];

while ($d = mysqli_fetch_assoc($data_chart)) {
    $labels[] = $d['tgl'];
    $values[] = $d['total'];
}

?>


<!DOCTYPE html>
<html>

<head>
    <title>Laporan Pembelian</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f5f0;
        }

        .card-custom {
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        /* BATIK COKLAT (BIAR BEDAIN DARI STAF) */
        .header-batik {
            background: linear-gradient(90deg, #5a3e2b, #8b5e3c);
            color: white;
            padding: 12px;
            border-bottom: 3px solid #d4af37;
        }

        .table thead {
            background: #5a3e2b;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #f2e9e1;
        }

        .dataTables_wrapper .dataTables_filter input {
            border-radius: 8px;
            padding: 5px 10px;
        }

        .dataTables_wrapper .dataTables_length select {
            border-radius: 8px;
        }
    </style>
</head>

<body>

    <div class="container mt-4">

        <h3 class="mb-4">Laporan Pembelian</h3>

        <form method="GET" action="" class="row mb-3">

            <input type="hidden" name="menu" value="laporan_pembelian">

            <div class="col-md-3">
                <label>Dari Tanggal</label>
                <input type="date" name="tgl_awal" value="<?= $tgl_awal ?>" class="form-control">
            </div>

            <div class="col-md-3">
                <label>Sampai Tanggal</label>
                <input type="date" name="tgl_akhir" value="<?= $tgl_akhir ?>" class="form-control">
            </div>

            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary me-2">Filter</button>
                <a href="?menu=laporan_pembelian" class="btn btn-secondary">Reset</a>
            </div>

        </form>

        <div class="card card-custom">
            <div class="header-batik">Data Transaksi Masuk</div>

            <div class="card-body">

                <table id="tabelLaporan" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID Transaksi</th>
                            <th>Tanggal</th>
                            <th>Petugas</th>
                            <th>Total Item</th>
                            <th>Detail</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $no = 1;
                        while ($row = mysqli_fetch_assoc($query)) { ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td>#TRX-<?= $row['id'] ?></td>
                                <td><?= $row['tanggal'] ?></td>
                                <td><?= $row['nama'] ?></td>
                                <td>
                                    <span class="badge bg-success">
                                        <?= $row['total_item'] ?> item
                                    </span>
                                </td>
                                <td>
                                    <a href="?menu=detail_pembelian&id=<?= $row['id'] ?>"
                                        class="btn btn-info btn-sm">
                                        Detail
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card card-custom mt-4 mb-5">
            <div class="header-batik text-center">
                <h4>Grafik Pembelian</h4>
            </div>

            <div class="card-body">
                <canvas id="chartPembelian"></canvas>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        $(document).ready(function() {
            $('#tabelLaporan').DataTable({
                "pageLength": 5,
                "lengthMenu": [5, 10, 25, 50],
                "ordering": true,
                "searching": true,
                "paging": true,
                "order": [
                    [1, "desc"]
                ],

                "language": {
                    "search": "Cari:",
                    "lengthMenu": "Tampilkan _MENU_ data",
                    "info": "Menampilkan _START_ - _END_ dari _TOTAL_ data",
                    "zeroRecords": "Data tidak ditemukan",
                    "paginate": {
                        "next": "Next",
                        "previous": "Prev"
                    }
                }
            });
        });
    </script>

    <script>
        const labels = <?= json_encode($labels); ?>;
        const data = <?= json_encode($values); ?>;

        new Chart(document.getElementById('chartPembelian'), {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Jumlah Transaksi',
                    data: data,
                    borderWidth: 2,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>

</body>

</html>