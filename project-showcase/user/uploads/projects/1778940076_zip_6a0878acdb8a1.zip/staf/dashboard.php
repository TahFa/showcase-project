<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit;
}

// hitung data
$total_produk = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM produk"));
$total_staf   = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM staf"));

// contoh dummy
$total_penjualan = 350;
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard UMKM</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
.card-box {
    border-radius: 15px;
    padding: 20px;
    background: #f8f9fa;
}
.badge-box {
    background: #0d6efd;
    color: white;
    padding: 5px 10px;
    font-weight: bold;
}
</style>
</head>

<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">Dashboard</a>

    <div class="collapse navbar-collapse">
      <ul class="navbar-nav me-auto">
        
        <li class="nav-item">
          <a class="nav-link" href="index.php?menu=produk">Produk</a>
        </li>

        <?php if ($_SESSION['level'] == 'staf') { ?>
        <li class="nav-item">
          <a class="nav-link" href="index.php?menu=transaksimasuk">Transaksi Poduk Masuk</a>
        </li>
        <?php } ?>

        <li class="nav-item">
          <a class="nav-link" href="#">Laporan</a>
        </li>

      </ul>

      <span class="text-white me-3">
        Halo, <b><?php echo $_SESSION['username']; ?></b>
      </span>
      <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
    </div>
  </div>
</nav>

<div class="container mt-4">

  <!-- 🔥 PANGGIL MENU -->
  <?php include "menu.php"; ?>

  <!-- Welcome -->
  <div class="card mt-4 p-4">
    <h4>Selamat Datang di Dashboard</h4>
    <p>
      Anda login sebagai <b><?php echo $_SESSION['username']; ?></b>.
      Gunakan menu di atas untuk mengelola data produk, staf, dan laporan.
    </p>
  </div>

</div>

<?php
include"footer.php";
?>
</body>
</html>