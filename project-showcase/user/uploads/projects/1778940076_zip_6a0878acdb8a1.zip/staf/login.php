<?php 

// ambil pesan error kalau ada
$error = "";
if (isset($_GET['error'])) {
    $error = $_GET['error'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login Staf</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container d-flex justify-content-center align-items-center vh-100">

  <div class="card p-4 shadow" style="width: 350px;">
    <h4 class="text-center mb-3">Login Staf</h4>

    <!-- Pesan Error -->
    <?php if ($error != "") { ?>
      <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php } ?>

    <form method="POST" action="proses_login.php">

      <div class="mb-3">
        <label>Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>

      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>

      <div class="mb-3">
        <label>Captcha</label><br>
        <img src="captcha.php" class="mb-2">
        <input type="text" name="captcha" class="form-control" placeholder="Masukkan captcha" required>
      </div>

      <button type="submit" class="btn btn-primary w-100">Login</button>

    </form>
  </div>

</div>

</body>
</html>