<!-- FOOTER -->
<footer class="bg-primary text-white mt-5">
  <div class="container py-4">

    <div class="row">

      <!-- BRAND -->
      <div class="col-md-4 mb-3">
        <h5 class="fw-bold">Sistem UMKM</h5>
        <p class="small">
          Aplikasi manajemen produk untuk membantu UMKM mengelola data dengan mudah, cepat, dan efisien.
        </p>
      </div>

      <!-- SITEMAP -->
      <div class="col-md-4 mb-3">
        <h6 class="fw-semibold">Sitemap</h6>
        <ul class="list-unstyled">
          <li><a href="index.php" class="text-white text-decoration-none">Dashboard</a></li>
          <li><a href="index.php?menu=produk" class="text-white text-decoration-none">Data Produk</a></li>
          <li><a href="index.php?menu=tambah_produk" class="text-white text-decoration-none">Tambah Produk</a></li>
          <li><a href="index.php?menu=staf" class="text-white text-decoration-none">Data Staf</a></li>
        </ul>
      </div>

      <!-- KONTAK -->
      <div class="col-md-4 mb-3">
        <h6 class="fw-semibold">Kontak</h6>
        <p class="small mb-1">📍 Indonesia</p>
        <p class="small mb-1">📧 admin@umkm.com</p>
        <p class="small">📞 08xxxxxxxxxx</p>
      </div>

    </div>

    <hr class="border-light">

    <!-- COPYRIGHT -->
    <div class="text-center small">
      © <?= date('Y') ?> Sistem UMKM | All Rights Reserved
    </div>

  </div>
</footer>