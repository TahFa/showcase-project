<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
include "koneksi.php"; 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Produk</title>

    <!-- ✅ Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- ✅ DataTables Bootstrap 5 CSS -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">

  <!-- HEADER -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">📦 Data Produk</h3>

    <div class="d-flex gap-2">
      <a href="javascript:history.back()" class="btn btn-secondary">Kembali</a>
      <a href="?menu=tambah_produk" class="btn btn-primary btn-sm">+ Tambah</a>
    </div>
  </div>

  <!-- TABEL -->
  <div class="card shadow-sm">
    <div class="card-body">

      <div class="table-responsive">
        <table id="myTable" class="table table-striped table-hover align-middle">
          <thead class="table-dark">
            <tr>
              <th>No</th>
              <th>Gambar</th>
              <th>Nama</th>
              <th>Harga</th>
              <th>Stok</th>
              <th class="text-center">Aksi</th>
            </tr>
          </thead>
          <tbody>

            <?php
            $no = 1;
            $data = $conn->query("SELECT * FROM produk ORDER BY id DESC");
            while($row = $data->fetch_assoc()){
            ?>

            <tr>
              <td><?= $no++ ?></td>
              <td>
                <img src="../admin/gambar/<?= $row['gambar'] ?>" width="70" class="rounded">
              </td>
              <td><?= $row['nama'] ?></td>
              <td class="text-success fw-semibold">
                Rp <?= number_format($row['harga']) ?>
              </td>
              <td>
                <span class="badge bg-info text-dark">
                  <?= $row['stok'] ?>
                </span>
              </td>
              <td class="text-center">

                <a href="index.php?menu=edit_produk&id=<?= $row['id'] ?>" 
                   class="btn btn-warning btn-sm">Edit</a>

                <a href="index.php?menu=hapus_produk&id=<?= $row['id'] ?>" 
                   class="btn btn-danger btn-sm"
                   onclick="return confirm('Hapus?')">Hapus</a>

              </td>
            </tr>

            <?php } ?>

          </tbody>
        </table>
      </div>

    </div>
  </div>

</div>

<!-- ✅ jQuery (WAJIB DULUAN) -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

<!-- ✅ Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- ✅ DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<!-- ✅ DataTables Bootstrap 5 -->
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<!-- ✅ INIT DATATABLE -->
<script>
$(document).ready(function() {
    $('#myTable').DataTable({
        pageLength: 5,
        lengthMenu: [5, 10, 25, 50],
        language: {
            search: "🔍 Cari:",
            lengthMenu: "Tampilkan _MENU_ data",
            zeroRecords: "Data tidak ditemukan",
            info: "Menampilkan _START_ - _END_ dari _TOTAL_ data",
            paginate: {
                next: "Next",
                previous: "Prev"
            }
        }
    });
});
</script>

</body>
</html>