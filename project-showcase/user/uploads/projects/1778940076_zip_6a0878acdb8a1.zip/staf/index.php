<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// cek login
if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
    
    // kirim menu ke dashboard
    $menu = $_GET['menu'] ?? '';
    
    include "dashboard.php";

} else {
    include "login.php";
}
?>