<?php
include "koneksi.php";

$id = $_POST['id'];
$nama = $_POST['nama'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

if($_FILES['gambar']['name'] != ""){
  $gambar = time().'_'.$_FILES['gambar']['name'];
  $tmp = $_FILES['gambar']['tmp_name'];
  move_uploaded_file($tmp, "gambar/".$gambar);

  $conn->query("UPDATE produk SET nama='$nama', harga='$harga', stok='$stok', gambar='$gambar' WHERE id=$id");
}else{
  $conn->query("UPDATE produk SET nama='$nama', harga='$harga', stok='$stok' WHERE id=$id");
}

header("Location: index.php?menu=produk");
?>