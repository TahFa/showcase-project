<?php
session_start();
include "koneksi.php";

// Cek session staf
if (!isset($_SESSION['username']) || $_SESSION['role'] != 'staf') {
    header("Location: login_staf.php");
    exit;
}

// Inisialisasi keranjang
if (!isset($_SESSION['keranjang'])) {
    $_SESSION['keranjang'] = [];
}

// Tambah produk ke keranjang
if (isset($_POST['tambah_keranjang'])) {
    $id_produk = $_POST['id_produk'];
    $jumlah = (int)$_POST['jumlah'];

    if ($jumlah < 1) {
        echo "<script>alert('Jumlah minimal 1');window.location='produk_masuk.php';</script>";
        exit;
    }

    if (isset($_SESSION['keranjang'][$id_produk])) {
        $_SESSION['keranjang'][$id_produk] += $jumlah;
    } else {
        $_SESSION['keranjang'][$id_produk] = $jumlah;
    }

    header("Location: produk_masuk.php");
    exit;
}

// Hapus produk dari keranjang
if (isset($_GET['hapus'])) {
    $id_produk = $_GET['hapus'];
    unset($_SESSION['keranjang'][$id_produk]);
    header("Location: produk_masuk.php");
    exit;
}

// Simpan transaksi
if (isset($_POST['simpan_transaksi'])) {
    if (empty($_SESSION['keranjang'])) {
        echo "<script>alert('Keranjang kosong');window.location='produk_masuk.php';</script>";
        exit;
    }

    $tanggal = date('Y-m-d H:i:s');

    // Simpan transaksi utama
    $query_transaksi = mysqli_query($conn, "INSERT INTO transaksi_masuk (tanggal, id_staf) VALUES ('$tanggal','{$_SESSION['id_user']}')");
    $id_transaksi = mysqli_insert_id($conn);

    foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) {
        // Simpan detail transaksi
        mysqli_query($conn, "INSERT INTO detail_transaksi_masuk (id_transaksi, id_produk, jumlah) VALUES ('$id_transaksi','$id_produk','$jumlah')");

        // Update stok produk
        mysqli_query($conn, "UPDATE produk SET stok = stok + $jumlah WHERE id_produk='$id_produk'");
    }

    // Bersihkan keranjang
    $_SESSION['keranjang'] = [];
    echo "<script>alert('Transaksi berhasil disimpan!');window.location='produk_masuk.php';</script>";
    exit;
}

// Ambil semua produk
$produk = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Transaksi Produk Masuk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h2>Transaksi Produk Masuk (Staf)</h2>

    <!-- Form tambah produk ke keranjang -->
    <form method="post" class="mb-4">
        <div class="row g-2">
            <div class="col-md-6">
                <select name="id_produk" class="form-select" required>
                    <option value="">Pilih Produk</option>
                    <?php while ($p = mysqli_fetch_assoc($produk)) : ?>
                        <option value="<?= $p['id_produk'] ?>"><?= $p['nama_produk'] ?> (Stok: <?= $p['stok'] ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-3">
                <input type="number" name="jumlah" class="form-control" placeholder="Jumlah" min="1" required>
            </div>
            <div class="col-md-3">
                <button type="submit" name="tambah_keranjang" class="btn btn-primary w-100">Tambah ke Keranjang</button>
            </div>
        </div>
    </form>

    <!-- Tabel keranjang -->
    <h4>Keranjang</h4>
    <form method="post">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th>Jumlah</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($_SESSION['keranjang'])): ?>
                    <?php foreach ($_SESSION['keranjang'] as $id_produk => $jumlah): ?>
                        <?php 
                        $prod = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM produk WHERE id_produk='$id_produk'")); 
                        ?>
                        <tr>
                            <td><?= $prod['nama_produk'] ?></td>
                            <td><?= $jumlah ?></td>
                            <td><a href="?hapus=<?= $id_produk ?>" class="btn btn-danger btn-sm">Hapus</a></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" class="text-center">Keranjang kosong</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if (!empty($_SESSION['keranjang'])): ?>
        <button type="submit" name="simpan_transaksi" class="btn btn-success">Simpan Transaksi</button>
        <?php endif; ?>
    </form>
</body>
</html>