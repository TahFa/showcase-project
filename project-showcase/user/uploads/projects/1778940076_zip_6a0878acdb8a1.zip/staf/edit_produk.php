<?php
include "koneksi.php";

$id = $_GET['id'] ?? 0;

if(!$id){
    echo "ID tidak ditemukan";
    exit;
}

// ambil data produk
$data = $conn->query("SELECT * FROM produk WHERE id=$id");
$row = $data->fetch_assoc();

if(!$row){
    echo "Data tidak ditemukan";
    exit;
}

// 🔥 PREV & NEXT
$prev = $conn->query("SELECT id FROM produk WHERE id < $id ORDER BY id DESC LIMIT 1")->fetch_assoc();
$next = $conn->query("SELECT id FROM produk WHERE id > $id ORDER BY id ASC LIMIT 1")->fetch_assoc();
?>

<div class="container mt-5">
  <h3>Edit Produk</h3>

  <!-- 🔥 NAVIGASI -->
  <div class="mb-3 d-flex gap-2">
    <?php if($prev){ ?>
      <a href="index.php?menu=edit_produk&id=<?= $prev['id'] ?>" class="btn btn-outline-primary btn-sm">← Prev</a>
    <?php } ?>

    <?php if($next){ ?>
      <a href="index.php?menu=edit_produk&id=<?= $next['id'] ?>" class="btn btn-outline-primary btn-sm">Next →</a>
    <?php } ?>
  </div>

  <form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $row['id'] ?>">

    <input type="text" name="nama" value="<?= $row['nama'] ?>" class="form-control mb-2" placeholder="Nama Produk">
    <input type="number" name="harga" value="<?= $row['harga'] ?>" class="form-control mb-2" placeholder="Harga">
    <input type="number" name="stok" value="<?= $row['stok'] ?>" class="form-control mb-2" placeholder="Stok">

    <img src="../admin/gambar/<?= $row['gambar'] ?>" width="100" class="mb-2"><br>

    <input type="file" name="gambar" class="form-control mb-2">

    <button type="submit" name="update" class="btn btn-success">Update</button>
    <a href="index.php?menu=produk" class="btn btn-secondary">Kembali</a>
  </form>
</div>

<?php
// 🔥 PROSES UPDATE
if(isset($_POST['update'])){
    $id    = $_POST['id'];
    $nama  = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok  = $_POST['stok'];

    $gambar = $_FILES['gambar']['name'];

    if($gambar != ""){
        move_uploaded_file($_FILES['gambar']['tmp_name'], "gambar/".$gambar);
        $conn->query("UPDATE produk SET 
            nama='$nama',
            harga='$harga',
            stok='$stok',
            gambar='$gambar'
            WHERE id=$id");
    } else {
        $conn->query("UPDATE produk SET 
            nama='$nama',
            harga='$harga',
            stok='$stok'
            WHERE id=$id");
    }

    echo "<script>
        alert('Data berhasil diupdate');
        window.location='index.php?menu=produk';
    </script>";
}
?>