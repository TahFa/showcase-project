 <div class="row g-4">

    <div class="col-md-4">
      <div class="card-box">
        <span class="badge-box">Total Produk</span>
        <h2><?php echo $total_produk; ?></h2>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card-box">
        <span class="badge-box">Total Staf</span>
        <h2><?php echo $total_staf; ?></h2>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card-box">
        <span class="badge-box">Total Penjualan</span>
        <h2><?php echo $total_penjualan; ?></h2>
      </div>
    </div>

  </div>