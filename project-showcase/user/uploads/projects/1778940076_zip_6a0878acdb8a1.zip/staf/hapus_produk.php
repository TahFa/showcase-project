<?php
include "koneksi.php";

$id = $_GET['id'];

$data = $conn->query("SELECT gambar FROM produk WHERE id=$id")->fetch_assoc();
unlink("gambar/".$data['gambar']);

$conn->query("DELETE FROM produk WHERE id=$id");

header("Location: produk.php");
?>