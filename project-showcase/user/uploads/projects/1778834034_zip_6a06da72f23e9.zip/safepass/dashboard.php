<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>SafePass Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>

<?php include "navbar.php"; ?>

<div class="dashboard">

    <!-- HEADER -->
    <div class="dashboard-header">

        <div>

            <div class="title">
                My Password Vault
            </div>

            <div class="subtitle">
                Semua password tersimpan dengan aman dan terenkripsi.
            </div>

        </div>

        <button class="add-btn">
            <i class="bi bi-plus-circle"></i>
            Add Password
        </button>

    </div>


    <!-- SEARCH -->
    <div class="search-wrapper">

        <div class="search-box">

            <i class="bi bi-search"></i>

            <input type="text" placeholder="Search website or username...">

        </div>

        <div class="password-count">
            Showing 1-6 of 24 passwords
        </div>

    </div>



    <!-- GRID -->
    <div class="vault-grid">


        <!-- CARD -->
        <div class="vault-card">

            <div class="app-icon">
                <i class="bi bi-instagram"></i>
            </div>

            <div class="website-name">
                Instagram
            </div>

            <div class="label">Username</div>
            <div class="value">najwa123</div>

            <div class="label">Password</div>
            <div class="value password">••••••••</div>

            <div class="card-actions">

                <button class="edit-btn">
                    <i class="bi bi-pencil-square"></i>
                    Edit
                </button>

                <button class="delete-btn">
                    <i class="bi bi-trash"></i>
                    Delete
                </button>

            </div>

        </div>



        <!-- CARD -->
        <div class="vault-card">

            <div class="app-icon">
                <i class="bi bi-envelope-fill"></i>
            </div>

            <div class="website-name">
                Gmail
            </div>

            <div class="label">Username</div>
            <div class="value">najwa@gmail.com</div>

            <div class="label">Password</div>
            <div class="value password">••••••••</div>

            <div class="card-actions">

                <button class="edit-btn">
                    Edit
                </button>

                <button class="delete-btn">
                    Delete
                </button>

            </div>

        </div>


    </div>

</div>

<script src="assets/js/auth.js"></script>

</body>
</html>