<?php
session_start();

// hapus semua session
session_unset();

// hancurkan session
session_destroy();

echo json_encode([
    "success" => true
]);
?>