<?php
session_start();
include '../koneksi.php';

// cek login
if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "success" => false,
        "message" => "Unauthorized"
    ]);

    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT ciphertext, iv, auth_tag
    FROM vaults
    WHERE user_id = ?
    LIMIT 1
");

$stmt->bind_param("i", $user_id);

$stmt->execute();

$result = $stmt->get_result();


// ======================
// VAULT DITEMUKAN
// ======================

if ($row = $result->fetch_assoc()) {

    echo json_encode([
        "success" => true,
        "data" => [
            "ciphertext" => $row['ciphertext'],
            "iv" => $row['iv'],
            "tag" => $row['auth_tag']
        ]
    ]);

} else {

    // vault kosong

    echo json_encode([
        "success" => true,
        "data" => null
    ]);
}

$stmt->close();
$conn->close();
?>