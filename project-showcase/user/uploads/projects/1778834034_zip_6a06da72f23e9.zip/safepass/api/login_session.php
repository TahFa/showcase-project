<?php
session_start();
include '../koneksi.php';

// ambil data JSON
$data = json_decode(file_get_contents("php://input"), true);

// validasi input
if (!isset($data['username'])) {

    echo json_encode([
        "success" => false,
        "message" => "Username wajib diisi"
    ]);

    exit;
}

$username = trim($data['username']);

// cari user
$stmt = $conn->prepare("
    SELECT id, username
    FROM users
    WHERE username = ?
");

$stmt->bind_param("s", $username);

$stmt->execute();

$result = $stmt->get_result();

// cek user ditemukan
if ($row = $result->fetch_assoc()) {

    // buat session
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['username'] = $row['username'];

    echo json_encode([
        "success" => true
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "User tidak ditemukan"
    ]);
}

$stmt->close();
$conn->close();
?>