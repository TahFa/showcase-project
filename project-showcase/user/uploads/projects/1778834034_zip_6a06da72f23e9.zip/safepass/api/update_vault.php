<?php
session_start();
include '../koneksi.php';

// cek login
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Unauthorized"
    ]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

// validasi
if (
    !isset($data['id']) ||
    !isset($data['ciphertext']) ||
    !isset($data['iv']) ||
    !isset($data['tag'])
) {
    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

$user_id = $_SESSION['user_id'];

$id = (int)$data['id'];
$ciphertext = $data['ciphertext'];
$iv = $data['iv'];
$tag = $data['tag'];

// update hanya milik user sendiri
$stmt = $conn->prepare("
    UPDATE vaults
    SET ciphertext = ?, iv = ?, auth_tag = ?
    WHERE id = ? AND user_id = ?
");

$stmt->bind_param(
    "sssii",
    $ciphertext,
    $iv,
    $tag,
    $id,
    $user_id
);

if ($stmt->execute()) {

    echo json_encode([
        "success" => true
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Gagal update vault"
    ]);
}

$stmt->close();
$conn->close();
?>