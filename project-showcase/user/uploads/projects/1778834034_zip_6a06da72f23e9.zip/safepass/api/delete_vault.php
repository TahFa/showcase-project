<?php
session_start();
include '../koneksi.php';

// cek login
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Unauthorized"
    ]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data['id'])) {

    echo json_encode([
        "success" => false,
        "message" => "ID vault wajib diisi"
    ]);

    exit;
}

$user_id = $_SESSION['user_id'];
$id = (int)$data['id'];

// delete hanya milik user sendiri
$stmt = $conn->prepare("
    DELETE FROM vaults
    WHERE id = ? AND user_id = ?
");

$stmt->bind_param("ii", $id, $user_id);

if ($stmt->execute()) {

    echo json_encode([
        "success" => true
    ]);
} else {

    echo json_encode([
        "success" => false,
        "message" => "Gagal menghapus vault"
    ]);
}

$stmt->close();
$conn->close();
