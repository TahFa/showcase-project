<?php
session_start();
include '../koneksi.php';

// cek login
if (!isset($_SESSION['user_id'])) {

    echo json_encode([
        "success" => false,
        "message" => "Unauthorized"
    ]);

    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

// validasi input
if (
    !isset($data['ciphertext']) ||
    !isset($data['iv']) ||
    !isset($data['tag'])
) {

    echo json_encode([
        "success" => false,
        "message" => "Data tidak lengkap"
    ]);

    exit;
}

$user_id = $_SESSION['user_id'];

$ciphertext = $data['ciphertext'];
$iv = $data['iv'];
$tag = $data['tag'];


// ======================
// CEK APAKAH USER SUDAH PUNYA VAULT
// ======================

$checkStmt = $conn->prepare("
    SELECT id
    FROM vaults
    WHERE user_id = ?
");

$checkStmt->bind_param("i", $user_id);

$checkStmt->execute();

$result = $checkStmt->get_result();


// ======================
// JIKA SUDAH ADA → UPDATE
// ======================

if ($result->num_rows > 0) {

    $updateStmt = $conn->prepare("
        UPDATE vaults
        SET
            ciphertext = ?,
            iv = ?,
            auth_tag = ?
        WHERE user_id = ?
    ");

    $updateStmt->bind_param(
        "sssi",
        $ciphertext,
        $iv,
        $tag,
        $user_id
    );

    $success = $updateStmt->execute();

    $updateStmt->close();

} else {

    // ======================
    // JIKA BELUM ADA → INSERT
    // ======================

    $insertStmt = $conn->prepare("
        INSERT INTO vaults
        (user_id, ciphertext, iv, auth_tag)
        VALUES (?, ?, ?, ?)
    ");

    $insertStmt->bind_param(
        "isss",
        $user_id,
        $ciphertext,
        $iv,
        $tag
    );

    $success = $insertStmt->execute();

    $insertStmt->close();
}

$checkStmt->close();


// ======================
// RESPONSE
// ======================

if ($success) {

    echo json_encode([
        "success" => true
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Gagal menyimpan vault"
    ]);
}

$conn->close();
?>