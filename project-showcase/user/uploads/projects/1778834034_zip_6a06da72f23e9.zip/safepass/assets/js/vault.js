// SAVE VAULT
async function saveVault() {

    const site = document.getElementById("site").value.trim();
    const vaultUsername = document.getElementById("vault_username").value.trim();
    const vaultPassword = document.getElementById("vault_password").value.trim();

    if (!site || !vaultUsername || !vaultPassword) {
        alert("Semua field wajib diisi");
        return;
    }

    try {

        // ambil session key
        const key = getSessionKey();

        if (!key) {
            alert("Session key tidak ditemukan. Login ulang.");
            return;
        }

        // gabungkan data jadi JSON
        const vaultData = JSON.stringify({
            site: site,
            username: vaultUsername,
            password: vaultPassword
        });

        // encrypt data
        const encrypted = await encryptData(vaultData, key);

        // kirim ke backend
        const response = await fetch("api/save_vault.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(encrypted)
        });

        const result = await response.json();

        if (result.success) {
            alert("Vault berhasil disimpan");

            // reset form
            document.getElementById("site").value = "";
            document.getElementById("vault_username").value = "";
            document.getElementById("vault_password").value = "";

            // refresh vault
            loadVaults();

        } else {
            alert(result.message);
        }

    } catch (error) {
        console.error(error);
        alert("Gagal menyimpan vault");
    }
}


// LOAD VAULTS
async function loadVaults() {

    try {

        const key = getSessionKey();

        if (!key) {
            alert("Session key tidak ditemukan");
            return;
        }

        // ambil ciphertext dari backend
        const response = await fetch("api/get_vault.php");

        const result = await response.json();

        if (!result.success) {
            alert(result.message);
            return;
        }

        const vaultContainer = document.getElementById("vaultContainer");

        vaultContainer.innerHTML = "";

        // loop semua vault
        for (const item of result.data) {

            try {

                // decrypt data
                const decrypted = await decryptData({
                    ciphertext: item.ciphertext,
                    iv: item.iv,
                    tag: item.auth_tag
                }, key);

                const vault = JSON.parse(decrypted);

                // tampilkan ke UI
                vaultContainer.innerHTML += `
                    <div class="card mb-3 p-3">
                        <h5>${vault.site}</h5>

                        <p>
                            <strong>Username:</strong>
                            ${vault.username}
                        </p>

                        <p>
                            <strong>Password:</strong>
                            ${vault.password}
                        </p>

                        <button onclick="showUpdateForm(${item.id},
                        '${vault.site}',
                        '${vault.username}',
                        '${vault.password}')">
                            Edit
                        </button>

                        <button onclick="deleteVault(${item.id})">
                            Delete
                        </button>
                    </div>
                `;

            } catch (decryptError) {

                console.error("Decrypt gagal:", decryptError);

                vaultContainer.innerHTML += `
                    <div class="card mb-3 p-3 border-danger">
                        <p>Vault rusak / tidak valid</p>
                    </div>
                `;
            }
        }

    } catch (error) {
        console.error(error);
        alert("Gagal load vault");
    }
}


// UPDATE VAULT
async function updateVault(vaultId) {

    const site = document.getElementById("edit_site").value.trim();
    const username = document.getElementById("edit_username").value.trim();
    const password = document.getElementById("edit_password").value.trim();

    try {

        const key = getSessionKey();

        const updatedData = JSON.stringify({
            site: site,
            username: username,
            password: password
        });

        // encrypt ulang
        const encrypted = await encryptData(updatedData, key);

        // kirim ke backend
        const response = await fetch("api/update_vault.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: vaultId,
                ciphertext: encrypted.ciphertext,
                iv: encrypted.iv,
                tag: encrypted.tag
            })
        });

        const result = await response.json();

        if (result.success) {
            alert("Vault berhasil diupdate");
            loadVaults();
        } else {
            alert(result.message);
        }

    } catch (error) {
        console.error(error);
        alert("Gagal update vault");
    }
}


// DELETE VAULT
async function deleteVault(vaultId) {

    const confirmDelete = confirm("Hapus vault ini?");

    if (!confirmDelete) return;

    try {

        const response = await fetch("api/delete_vault.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                id: vaultId
            })
        });

        const result = await response.json();

        if (result.success) {
            alert("Vault berhasil dihapus");
            loadVaults();
        } else {
            alert(result.message);
        }

    } catch (error) {
        console.error(error);
        alert("Gagal menghapus vault");
    }
}