// SESSION KEY
let sessionKey = null;


// REGISTER
async function handleRegister() {

    const username = document
        .getElementById("username")
        .value
        .trim();

    const password = document
        .getElementById("password")
        .value;

    if (!username || !password) {

        alert("Username dan password wajib diisi");

        return;
    }

    try {

        // generate salt
        const salt = generateSalt();

        // derive key
        const key = await deriveKey(password, salt);

        // export key
        const passwordHash = await exportKey(key);

        // payload
        const payload = {
            username: username,
            password_hash: passwordHash,
            salt: bufferToBase64(salt),
            iterations: ITERATIONS
        };

        console.log(payload);

        // kirim ke backend
        const response = await fetch("api/register.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });

        const result = await response.json();

        console.log(result);

        if (result.success) {

            alert("Registrasi berhasil!");

            window.location.href = "login.php";

        } else {

            alert(result.message);
        }

    } catch (error) {
        
        console.error(error);
        alert("Error saat register");
    }
}


// LOGIN
async function handleLogin() {

    const username = document
        .getElementById("username")
        .value;

    const password = document
        .getElementById("password")
        .value;

    if (!username || !password) {

        alert("Username dan password wajib diisi");

        return;
    }

    try {

        const response = await fetch("api/get_user.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                username: username
            })
        });

        const result = await response.json();

        if (!result.success) {

            alert("User tidak ditemukan");

            return;
        }

        const user = result.data;

        const salt = base64ToBuffer(user.salt);

        const key = await deriveKey(password, salt);

        const computedHash = await exportKey(key);

        if (computedHash !== user.password_hash) {

            alert("Password salah!");

            return;
        }

        sessionKey = key;

        sessionStorage.setItem("login", "true");

        sessionStorage.setItem("username", username);

        const sessionResponse = await fetch(
            "api/login_session.php",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username: username
                })
            }
        );

        const sessionResult = await sessionResponse.json();

        if (!sessionResult.success) {

            alert("Gagal membuat session");

            return;
        }

        window.location.href = "dashboard.php";

    } catch (error) {

        console.error(error);

        alert("Error saat login");
    }
}


// LOGOUT
async function logoutUser() {

    try {

        await fetch("api/logout.php");

        sessionKey = null;

        sessionStorage.clear();

        window.location.href = "login.php";

    } catch (error) {

        console.error(error);

        alert("Gagal logout");
    }
}


// GET SESSION KEY
function getSessionKey() {
    return sessionKey;
}