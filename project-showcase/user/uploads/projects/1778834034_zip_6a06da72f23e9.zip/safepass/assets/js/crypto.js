const ITERATIONS = 100000;
const KEY_LENGTH = 256;


// CONVERT UTILITIES
function strToBuffer(str) {
    return new TextEncoder().encode(str);
}

function bufferToStr(buffer) {
    return new TextDecoder().decode(buffer);
}

function bufferToBase64(buffer) {

    let binary = '';

    const bytes = new Uint8Array(buffer);

    const len = bytes.byteLength;

    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }

    return btoa(binary);
}

function base64ToBuffer(base64) {

    const binary = atob(base64);

    const bytes = new Uint8Array(binary.length);

    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }

    return bytes;
}


// GENERATE SALT
function generateSalt() {
    return crypto.getRandomValues(new Uint8Array(16));
}


// DERIVE KEY (PBKDF2)
async function deriveKey(password, salt, iterations = ITERATIONS) {

    const keyMaterial = await crypto.subtle.importKey(
        "raw",
        strToBuffer(password),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
    );

    return await crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt,
            iterations: iterations,
            hash: "SHA-256"
        },
        keyMaterial,
        {
            name: "AES-GCM",
            length: KEY_LENGTH
        },
        true,
        ["encrypt", "decrypt"]
    );
}

// ENCRYPT DATA
async function encryptData(plainText, key) {

    try {

        const iv = crypto.getRandomValues(new Uint8Array(12));

        const encoded = strToBuffer(plainText);

        const encrypted = await crypto.subtle.encrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            key,
            encoded
        );

        const encryptedArray = new Uint8Array(encrypted);

        const ciphertext = encryptedArray.slice(
            0,
            encryptedArray.length - 16
        );

        const authTag = encryptedArray.slice(
            encryptedArray.length - 16
        );

        return {
            ciphertext: bufferToBase64(ciphertext),
            iv: bufferToBase64(iv),
            tag: bufferToBase64(authTag)
        };

    } catch (error) {

        console.error(error);

        throw new Error("Gagal mengenkripsi data");
    }
}


// DECRYPT DATA
async function decryptData(encryptedData, key) {

    try {

        const iv = base64ToBuffer(encryptedData.iv);

        const ciphertext = base64ToBuffer(encryptedData.ciphertext);

        const authTag = base64ToBuffer(encryptedData.tag);

        const combined = new Uint8Array(
            ciphertext.length + authTag.length
        );

        combined.set(ciphertext);

        combined.set(authTag, ciphertext.length);

        const decrypted = await crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: iv
            },
            key,
            combined
        );

        return bufferToStr(decrypted);

    } catch (error) {

        console.error(error);

        throw new Error(
            "Dekripsi gagal. Password salah atau data rusak."
        );
    }
}


// EXPORT KEY
async function exportKey(key) {

    const raw = await crypto.subtle.exportKey("raw", key);

    return bufferToBase64(raw);
}