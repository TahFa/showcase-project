<nav class="navbar-custom d-flex justify-content-between align-items-center">

    <div class="logo">
        <i class="bi bi-shield-lock-fill"></i>
        SafePass
    </div>

    <div class="nav-right">

        <div class="username">
            <i class="bi bi-person-circle"></i>
            <?= $_SESSION['username']; ?>
        </div>

        <button class="logout-btn" onclick="logoutUser()">
            Logout
        </button>

    </div>

</nav>