<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>UMKM Sejahtera</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f5f5f5;
        }

        /* HEADER */
        .topbar {
            background: #ffccff;
            color: white;
            font-size: 12px;
            padding: 5px 0;
        }

        .main-header {
            background: #ffccff;
            padding: 10px 0;
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }

        .search-box input {
            border-radius: 20px 0 0 20px;
        }

        .search-box button {
            border-radius: 0 20px 20px 0;
            background: #f4e0f4;
            border: none;
            color: white;
        }

        /* KATEGORI */
        .kategori-box {
            background: white;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
            transition: 0.3s;
        }

        .kategori-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .kategori-box img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            margin-bottom: 10px;
        }

        /* PRODUK */
        .produk-card {
            border: none;
            border-radius: 10px;
            transition: 0.3s;
        }

        .produk-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .produk-img {
            height: 150px;
            object-fit: cover;
        }
    </style>
</head>

<body>

    <!-- TOPBAR -->
    <div class="topbar text-center">
        UMKM Sejahtera | Dukung Produk Lokal 🇮🇩
    </div>

    <!-- HEADER -->
    <div class="main-header">
        <div class="container">

            <div class="row align-items-center">

                <!-- LOGO -->
                <div class="col-4 col-md-3">
                    <div class="logo">UMKM</div>
                </div>

                <!-- SEARCH -->
                <div class="col-8 col-md-6">
                    <form class="d-flex search-box">
                        <input type="text" class="form-control" placeholder="Cari produk UMKM...">
                        <button type="submit" class="btn">
                            🔍
                        </button>
                    </form>
                </div>

                <!-- MENU -->
                <div class="col-md-3 d-none d-md-block text-end text-white">
                    Login | Daftar
                </div>

            </div>

        </div>
    </div>

    <!-- MENU FITUR CEPAT -->
    <div class="container mt-3">

        <div class="bg-white p-3 rounded shadow-sm">

            <div class="d-flex overflow-auto text-center">

                <?php
                $fitur = [
                    ["Produk Lokal", "❤️"],
                    ["UMKM Mall", "🛍️"],
                    ["Tagihan", "📱"],
                    ["Flash Sale", "⚡"],
                    ["Supermarket", "🛒"],
                    ["Dikelola UMKM", "🏪"],
                    ["Diskon", "🏷️"],
                    ["Voucher", "🎟️"],
                    ["UMKM Halal", "🕌"],
                    ["Promo", "🔥"]
                ];

                foreach ($fitur as $f) {
                ?>

                    <div class="me-4" style="min-width:80px;">
                        <div class="p-2 border rounded" style="font-size: 20px;">
                            <?php echo $f[1]; ?>
                        </div>
                        <small><?php echo $f[0]; ?></small>
                    </div>

                <?php } ?>

            </div>

        </div>

    </div>

    <!-- KATEGORI -->
    <div class="container mt-4">

        <h5 class="mb-3">Kategori</h5>

        <div class="row g-3">

            <?php
            $kategori = [
                ["Makanan", "https://cdn-icons-png.flaticon.com/512/1046/1046784.png"],
                ["Fashion", "https://cdn-icons-png.flaticon.com/512/892/892458.png"],
                ["Elektronik", "https://cdn-icons-png.flaticon.com/512/3659/3659898.png"],
                ["Kerajinan", "https://cdn-icons-png.flaticon.com/512/3468/3468377.png"],
                ["Minuman", "https://cdn-icons-png.flaticon.com/512/2935/2935307.png"],
                ["Kosmetik", "https://cdn-icons-png.flaticon.com/512/3081/3081559.png"]
            ];

            foreach ($kategori as $k) {
            ?>

                <div class="col-4 col-md-2">
                    <div class="kategori-box">
                        <img src="<?php echo $k[1]; ?>">
                        <div><?php echo $k[0]; ?></div>
                    </div>
                </div>

            <?php } ?>

        </div>
    </div>

    <!-- PRODUK -->
    <div class="container mt-4">

        <h5 class="mb-3">Produk Terbaru</h5>

        <div class="row g-3">
            <?php
            include "admin/koneksi.php";

            $data = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC");

            while ($p = mysqli_fetch_assoc($data)) {
            ?>

                <div class="col-6 col-md-4 col-lg-3">
                    <div class="card produk-card">

                        <!-- GAMBAR -->
                        <img src="admin/gambar/<?php echo $p['gambar']; ?>"
                            class="card-img-top produk-img"
                            onerror="this.src='https://via.placeholder.com/300x200'">

                        <div class="card-body">

                            <!-- NAMA -->
                            <h6><?php echo $p['nama_produk']; ?></h6>

                            <!-- HARGA -->
                            <p class="text-danger fw-bold">
                                Rp <?php echo number_format($p['harga']); ?>
                            </p>

                            <!-- STOK -->
                            <small class="text-muted">
                                Stok: <?php echo $p['stok']; ?>
                            </small>

                            <!-- BUTTON -->
                            <button class="btn btn-sm btn-outline-primary w-100 mt-2"> 
                                Beli
                            </button>

                        </div>

                    </div>
                </div>

            <?php } ?>

        </div>

    </div>

    <!-- FOOTER -->
    <footer class="bg-dark text-white mt-5 p-4 text-center">
        UMKM Sejahtera © 2026 <br>
        Email: umkm@gmail.com | Telp: 08123456789
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>