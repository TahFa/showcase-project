<!DOCTYPE html>
<html>

<head>
    <title>Login Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: linear-gradient(135deg, #ecc7f7, #b8eeff);
            height: 100vh;
        }

        .login-box {
            margin-top: 120px;
            background: white;
            padding: 35px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
    </style>

</head>

<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">

                <div class="login-box">

                    <h3 class="text-center mb-4">Login Admin</h3>

                    <form action="proses_login.php" method="POST">

                        <div class="mb-3">
                            <label>Username</label>
                            <input type="text" name="username" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label>Captcha</label><br>
                            <img src="captcha.php" class="mb-2">
                            <input type="text" name="captcha" class="form-control" placeholder="Masukkan captcha" required>
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Login</button>

                    </form>

                </div>

            </div>
        </div>
    </div>

</body>

</html>