<footer class="footer-pink mt-5 pt-4 pb-3">
    <div class="container">

        <div class="row">

            <!-- INFO SISTEM -->
            <div class="col-md-3">
                <h5>Admin Panel</h5>
                <p>
                    Sistem manajemen untuk mengelola produk,
                    staf, dan laporan pada aplikasi UMKM.
                </p>
            </div>

            <!-- SITEMAP -->
            <div class="col-md-3">
                <h5>Sitemap</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="text-decoration-none">Dashboard</a></li>
                    <li><a href="index.php?menu=produk" class="text-decoration-none">Produk</a></li>
                    <li><a href="index.php?menu=staf" class="text-decoration-none">Staf</a></li>
                </ul>
            </div>

            <!-- LAPORAN -->
            <div class="col-md-3">
                <h5>Laporan</h5>
                <ul class="list-unstyled">
                    <li><a href="laporan_penjualan.php" class="text-decoration-none">Laporan Penjualan</a></li>
                    <li><a href="laporan_produk.php" class="text-decoration-none">Laporan Produk</a></li>
                    <li><a href="laporan_staf.php" class="text-decoration-none">Laporan Staf</a></li>
                </ul>
            </div>

            <!-- INFORMASI -->
            <div class="col-md-3">
                <h5>Informasi</h5>
                <ul class="list-unstyled">
                    <li>📞 Telp : 0812-3456-7890</li>
                    <li>✉ Email : admin@umkm.com</li>
                </ul>
            </div>

        </div>

        <hr>

        <div class="text-center">
            <small>
                © <?php echo date("Y"); ?> Admin UMKM | Sistem Informasi Manajemen
            </small>
        </div>

    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>