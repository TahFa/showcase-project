<?php

include "koneksi.php";

$id = $_POST['id_staf'];
$username = $_POST['username'];
$password = $_POST['password'];
$nama = $_POST['nama'];
$role = $_POST['role'];

mysqli_query($koneksi, "UPDATE staf SET
username='$username',
password='$password',
nama='$nama',
role='$role'
WHERE id_staf='$id'");

header("location:index.php?menu=staf");
