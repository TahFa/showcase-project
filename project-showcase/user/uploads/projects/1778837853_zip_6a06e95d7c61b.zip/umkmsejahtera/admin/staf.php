<?php
include "koneksi.php";
?>

<style>
    .card-box {
        background: #fff;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(255, 105, 180, 0.2);
    }

    h3 {
        color: #d63384;
        font-weight: bold;
    }

    /* Button Pink */
    .btn-pink {
        background: #ff4da6;
        color: white;
        border-radius: 10px;
        border: none;
        transition: 0.3s;
    }

    .btn-pink:hover {
        background: #e60073;
        transform: scale(1.05);
    }

    /* Table */
    .table thead {
        background: #ff4da6;
        color: white;
    }

    .table tbody tr:hover {
        background-color: #ffe6f0;
    }

    /* Badge Role */
    .badge-admin {
        background: #ff4d6d;
        padding: 6px 10px;
        border-radius: 10px;
    }

    .badge-staf {
        background: #ff99cc;
        color: #000;
        padding: 6px 10px;
        border-radius: 10px;
    }

    .badge-owner {
        background: #d63384;
        padding: 6px 10px;
        border-radius: 10px;
    }

    /* Aksi */
    .btn-warning {
        background: #ffb3d9;
        border: none;
    }

    .btn-danger {
        background: #ff4d6d;
        border: none;
    }

    /* DataTables */
    .dataTables_wrapper .dataTables_filter input {
        border-radius: 10px;
        border: 1px solid #ff99cc;
    }
</style>

<div class="container mt-4">

    <div class="card-box">

        <h3>Data Staf</h3>

        <div class="mb-3">
            <a href="index.php" class="btn btn-secondary">Kembali</a>
            <a href="?menu=tambah_staf" class="btn btn-pink">+ Tambah Staf</a>
        </div>

        <table id="tabelStaf" class="table table-hover text-center align-middle">

            <thead>
                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Nama</th>
                    <th>Role</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>

                <?php
                $no = 1;
                $data = mysqli_query($koneksi, "SELECT * FROM staf");

                while ($d = mysqli_fetch_array($data)) {
                ?>

                    <tr>

                        <td><?php echo $no++; ?></td>
                        <td><?php echo $d['username']; ?></td>
                        <td><?php echo $d['nama']; ?></td>

                        <td>
                            <?php
                            if ($d['role'] == "admin") {
                                echo "<span class='badge badge-admin'>Admin</span>";
                            } elseif ($d['role'] == "staf") {
                                echo "<span class='badge badge-staf'>Staf</span>";
                            } else {
                                echo "<span class='badge badge-owner'>Owner</span>";
                            }
                            ?>
                        </td>

                        <td>
                            <a href="?menu=edit_staf&id_staf=<?php echo $d['id_staf']; ?>"
                                class="btn btn-warning btn-sm">
                                Edit
                            </a>

                            <a href="hapus_staf.php?id_staf=<?php echo $d['id_staf']; ?>"
                                class="btn btn-danger btn-sm"
                                onclick="return confirm('Yakin ingin menghapus data?')">
                                Hapus
                            </a>
                        </td>

                    </tr>

                <?php } ?>

            </tbody>

        </table>

    </div>

</div>

<!-- DataTables -->
<link rel="stylesheet"
    href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $('#tabelStaf').DataTable({
            pageLength: 5,
            lengthMenu: [5, 10, 25, 50]
        });
    });
</script>