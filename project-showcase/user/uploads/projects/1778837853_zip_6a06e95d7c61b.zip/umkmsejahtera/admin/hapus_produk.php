<?php
include "koneksi.php";

$id = $_GET['id'];

// ambil data produk dulu untuk ambil nama gambar
$data = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk='$id'");
$d = mysqli_fetch_array($data);

// hapus gambar dari folder
if ($d['gambar'] != "") {
    unlink("gambar/" . $d['gambar']);
}

// hapus data dari database
mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk='$id'");

// kembali ke halaman produk
header("location:produk.php");
