  <div class="container mt-4">

        <h3 class="mb-4">Dashboard Admin</h3>

        <div class="row">

            <div class="col-md-4">
                <div class="card card-dashboard p-3">
                    <h5>Total Produk</h5>
                    <h3>120</h3>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-dashboard p-3">
                    <h5>Total Staf</h5>
                    <h3>10</h3>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card card-dashboard p-3">
                    <h5>Total Penjualan</h5>
                    <h3>350</h3>
                </div>
            </div>

        </div>

    </div>

    <div class="container mt-4">

        <div class="welcome-box">

            <h4>Selamat Datang di Dashboard</h4>

            <p>
                Anda login sebagai <b><?php echo $nama; ?></b>.
                Gunakan menu di atas untuk mengelola data produk, staf, dan laporan.
            </p>

        </div>

    </div>