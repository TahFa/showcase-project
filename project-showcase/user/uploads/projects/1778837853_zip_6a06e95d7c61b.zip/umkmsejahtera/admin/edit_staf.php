<?php
include "koneksi.php";

$id = $_GET['id_staf'];

$data = mysqli_query($koneksi, "SELECT * FROM staf WHERE id_staf='$id'");
$d = mysqli_fetch_array($data);
?>

<div class="container mt-4">

    <style>
        /* BOX */
        .form-box {
            background: #f3f3f3;
            padding: 30px;
            border-radius: 20px;
        }

        /* TITLE */
        .title {
            color: #e83e8c;
            font-weight: bold;
            margin-bottom: 20px;
        }

        /* INPUT */
        .custom-input {
            border-radius: 12px;
            border: 1px solid #ff99cc;
            padding: 10px;
        }

        .custom-input:focus {
            border-color: #ff4da6;
            box-shadow: none;
        }

        /* BUTTON PINK */
        .btn-pink {
            background: #ff4da6;
            color: white;
            border: none;
            border-radius: 12px;
            padding: 8px 18px;
            font-weight: 500;
        }

        .btn-pink:hover {
            background: #ff3385;
            color: white;
        }

        /* BUTTON SECONDARY */
        .btn-secondary {
            border-radius: 12px;
            padding: 8px 18px;
        }
    </style>

    <div class="form-box">

        <h2 class="title">Edit Staf</h2>

        <form action="update_staf.php" method="POST">

            <input type="hidden" name="id_staf" value="<?php echo $d['id_staf']; ?>">

            <div class="mb-3">
                <label>Username</label>
                <input type="text"
                    name="username"
                    class="form-control custom-input"
                    value="<?php echo $d['username']; ?>"
                    required>
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="text"
                    name="password"
                    class="form-control custom-input"
                    value="<?php echo $d['password']; ?>"
                    required>
            </div>

            <div class="mb-3">
                <label>Nama</label>
                <input type="text"
                    name="nama"
                    class="form-control custom-input"
                    value="<?php echo $d['nama']; ?>">
            </div>

            <div class="mb-3">
                <label>Role</label>
                <select name="role" class="form-control custom-input">

                    <option value="admin" <?php if ($d['role'] == "admin") echo "selected"; ?>>
                        Admin
                    </option>

                    <option value="staf" <?php if ($d['role'] == "staf") echo "selected"; ?>>
                        Staf
                    </option>

                    <option value="pemilik" <?php if ($d['role'] == "pemilik") echo "selected"; ?>>
                        Owner
                    </option>

                </select>
            </div>

            <button type="submit" class="btn btn-pink">
                ✏️ Update
            </button>

            <a href="?menu=staf" class="btn btn-secondary ms-2">
                Kembali
            </a>

        </form>

    </div>

</div>