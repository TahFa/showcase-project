<?php

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$nama = isset($_SESSION['nama']) ? $_SESSION['nama'] : "User";
?>

<!DOCTYPE html>
<html>

<head>
    <title>Dashboard Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
        }

        .card-dashboard {
            border: none;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .card-dashboard:hover {
            transform: translateY(-4px);
            transition: 0.3s;
        }

        /* NAVBAR */
        .navbar-custom {
            background: linear-gradient(90deg, #ff4da6, #ff80bf);
            padding: 12px 0;
        }

        /* Brand & link */
        .navbar-custom .nav-link,
        .navbar-custom .navbar-brand {
            color: white !important;
            font-weight: 500;
        }

        /* Hover effect */
        .navbar-custom .nav-link:hover {
            color: #ffe6f0 !important;
        }

        /* Active menu */
        .navbar-custom .nav-link.active {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 5px 10px;
        }

        /* Dropdown */
        .navbar-custom .dropdown-menu {
            border-radius: 10px;
            border: none;
        }

        .navbar-custom .dropdown-item:hover {
            background: #ffe6f0;
        }

        /* Logout button */
        .btn-Logout {
            background: white;
            color: #d63384;
            border-radius: 20px;
            padding: 5px 15px;
            font-weight: 600;
            border: none;
        }

        .btn-Logout:hover {
            background: #ffe6f0;
        }

        .btn-light:hover {
            transform: scale(1.05);
        }

        .footer-pink {
            background: linear-gradient(90deg, #ff4da6, #ff80bf);
            color: white;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }

        /* Judul */
        .footer-pink h5 {
            font-weight: bold;
            margin-bottom: 15px;
        }

        /* Link */
        .footer-pink a {
            color: white;
            transition: 0.3s;
        }

        .footer-pink a:hover {
            color: #ffe6f0;
            padding-left: 5px;
        }

        /* List */
        .footer-pink ul li {
            margin-bottom: 8px;
        }

        /* Garis */
        .footer-pink hr {
            border-top: 1px solid rgba(255, 255, 255, 0.5);
        }

        /* Copyright */
        .footer-pink small {
            opacity: 0.9;
        }
    </style>

</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">

            <a class="navbar-brand fw-bold" href="#">Admin Panel</a>

            <button class="navbar-toggler bg-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                ☰
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">

                <ul class="navbar-nav me-auto">

                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Dashboard</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="index.php?menu=produk">Produk</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="index.php?menu=staf">Staf</a>
                    </li>

                    <!-- DROPDOWN LAPORAN -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            Laporan
                        </a>

                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="laporan_penjualan.php">Laporan Penjualan</a></li>
                            <li><a class="dropdown-item" href="laporan_produk.php">Laporan Produk</a></li>
                            <li><a class="dropdown-item" href="laporan_staf.php">Laporan Staf</a></li>
                        </ul>
                    </li>

                </ul>

                <!-- HALO USER -->
                <span class="text-white me-3">
                    Halo, <b><?php echo $nama; ?></b>!
                </span>

                <a href="logout.php" class="btn btn-Logout btn-sm">
                    Logout
                </a>

            </div>
        </div>
    </nav>

    <!-- CONTENT -->
    <?php
    include "menu.php";
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <?php
    include "footer.php";
    ?>

</body>

</html>