<?php

include "koneksi.php";

$username = $_POST['username'];
$password = md5($_POST['password']);
$nama = $_POST['nama'];
$role = $_POST['role'];

mysqli_query($koneksi, "INSERT INTO staf
(username,password,nama,role)
VALUES
('$username','$password','$nama','$role')");

header("location:index.php?menu=staf");
