<?php
include "koneksi.php";

$id = $_POST['id_produk'];
$nama = $_POST['nama_produk'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

$gambar = $_FILES['gambar']['name'];
$tmp = $_FILES['gambar']['tmp_name'];

if($gambar != ""){

    move_uploaded_file($tmp, "gambar/".$gambar);

    mysqli_query($koneksi, "UPDATE produk SET
        nama_produk='$nama',
        harga='$harga',
        stok='$stok',
        gambar='$gambar'
        WHERE id_produk='$id'
    ");

}else{

    mysqli_query($koneksi, "UPDATE produk SET
        nama_produk='$nama',
        harga='$harga',
        stok='$stok'
        WHERE id_produk='$id'
    ");
}

header("location:index.php?menu=produk");