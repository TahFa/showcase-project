<?php

include "koneksi.php";

$id = $_GET['id_staf'];

mysqli_query($koneksi, "DELETE FROM staf WHERE id_staf='$id'");

header("location:index.php?menu=staf");
