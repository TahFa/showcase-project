<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html>

<head>
    <title>Data Produk</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">

    <style>
        body {
            background: #fff0f6;
            font-family: 'Segoe UI', sans-serif;
        }

        .card-box {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(255, 105, 180, 0.2);
        }

        h2 {
            color: #d63384;
            font-weight: bold;
        }

        /* Button */
        .btn-pink {
            background: #ff4da6;
            color: white;
            border-radius: 10px;
            border: none;
            transition: 0.3s;
        }

        .btn-pink:hover {
            background: #e60073;
            transform: scale(1.05);
        }

        .btn-secondary {
            border-radius: 10px;
        }

        /* Table */
        .table thead {
            background: #ff4da6;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #ffe6f0;
        }

        /* Gambar */
        .table img {
            border-radius: 10px;
            transition: 0.3s;
        }

        .table img:hover {
            transform: scale(1.1);
        }

        /* DataTables styling */
        .dataTables_wrapper .dataTables_filter input {
            border-radius: 10px;
            border: 1px solid #ff99cc;
        }

        .dataTables_wrapper .dataTables_length select {
            border-radius: 10px;
        }
    </style>

</head>

<body>

    <div class="container mt-4">

        <div class="card-box">

            <h2>Data Produk</h2>

            <div class="mb-3">
                <a href="index.php" class="btn btn-secondary"> Kembali </a>
                <a href="?menu=tambah_produk" class="btn btn-pink">+ Tambah Produk</a>
            </div>

            <table id="tabelProduk" class="table table-hover text-center align-middle">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Gambar</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php
                    $no = 1;
                    $data = mysqli_query($koneksi, "SELECT * FROM produk");

                    while ($d = mysqli_fetch_array($data)) {
                    ?>

                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $d['nama_produk']; ?></td>
                            <td>Rp <?php echo number_format($d['harga']); ?></td>
                            <td><?php echo $d['stok']; ?></td>

                            <td>
                                <img src="gambar/<?php echo $d['gambar']; ?>" width="80">
                            </td>

                            <td>
                                <a href="?menu=edit_produk&id=<?php echo $d['id_produk']; ?>"
                                    class="btn btn-pink btn-sm">
                                    Edit
                                </a>

                                <a href="hapus_produk.php?id=<?php echo $d['id_produk']; ?>"
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Yakin ingin menghapus produk ini?')">
                                    Hapus
                                </a>
                            </td>
                        </tr>

                    <?php } ?>

                </tbody>

            </table>

        </div>

    </div>


    <!-- JQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#tabelProduk').DataTable({
                responsive: true,
                pageLength: 5,
                lengthMenu: [5, 10, 25, 50]
            });
        });
    </script>

</body>

</html>