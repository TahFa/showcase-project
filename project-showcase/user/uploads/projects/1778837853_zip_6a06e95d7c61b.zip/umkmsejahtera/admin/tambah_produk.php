<?php
include "koneksi.php";

if (isset($_POST['simpan'])) {

    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];

    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];

    move_uploaded_file($tmp, "upload/" . $gambar);

    mysqli_query($koneksi, "INSERT INTO produk VALUES('','$nama','$harga','$stok','$gambar')");

    header("location:produk.php");
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Tambah Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #fff0f6;
        }

        .card-box {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(255, 105, 180, 0.2);
        }

        h3 {
            color: #d63384;
            font-weight: bold;
        }

        /* Input */
        .form-control {
            border-radius: 10px;
            border: 1px solid #ff99cc;
        }

        .form-control:focus {
            border-color: #ff4da6;
            box-shadow: 0 0 5px rgba(255, 77, 166, 0.5);
        }

        /* Button */
        .btn-pink {
            background: #ff4da6;
            color: white;
            border: none;
            border-radius: 10px;
            transition: 0.3s;
        }

        .btn-pink:hover {
            background: #e60073;
            transform: scale(1.05);
        }

        .btn-secondary {
            border-radius: 10px;
        }

        /* Preview */
        .preview-img {
            margin-top: 10px;
            max-width: 120px;
            border-radius: 10px;
            display: none;
        }
    </style>
</head>

<body>

    <div class="container mt-4">

        <div class="card-box">

            <h3>Tambah Produk</h3>

            <form action="" method="POST" enctype="multipart/form-data">

                <div class="mb-3">
                    <label>Nama Produk</label>
                    <input type="text" name="nama" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Harga</label>
                    <input type="number" name="harga" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Stok</label>
                    <input type="number" name="stok" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Gambar Produk</label>
                    <input type="file" name="gambar" class="form-control" onchange="previewImage(event)" required>

                    <img id="preview" class="preview-img">
                </div>

                <button type="submit" name="simpan" class="btn btn-pink">
                    💾 Simpan
                </button>

                <a href="?menu=produk" class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>

    </div>

    <script>
        function previewImage(event) {
            const reader = new FileReader();
            reader.onload = function() {
                const img = document.getElementById('preview');
                img.src = reader.result;
                img.style.display = 'block';
            }
            reader.readAsDataURL(event.target.files[0]);
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>