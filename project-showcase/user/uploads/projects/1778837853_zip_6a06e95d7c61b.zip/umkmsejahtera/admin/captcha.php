<?php
session_start();

$characters = 'abcdefghjkmnopqrstuvwxyzABCDEFGHJKMNOPQRSTUVWXYZ';
$captcha = substr(str_shuffle($characters), 0, 4);

$_SESSION['captcha'] = $captcha;

header('Content-type: image/png');

$image = imagecreate(100, 40);
$bg = imagecolorallocate($image, 255, 255, 255);
$textcolor = imagecolorallocate($image, 0, 0, 0);

imagestring($image, 5, 25, 10, $captcha, $textcolor);

imagepng($image);
imagedestroy($image);
