<div class="container mt-4">

    <style>
        /* BOX UTAMA */
        .form-box {
            background: #f3f3f3;
            padding: 30px;
            border-radius: 20px;
        }

        /* JUDUL */
        .title {
            color: #e83e8c;
            font-weight: bold;
            margin-bottom: 20px;
        }

        /* INPUT */
        .custom-input {
            border-radius: 12px;
            border: 1px solid #ff99cc;
            padding: 10px;
        }

        .custom-input:focus {
            border-color: #ff4da6;
            box-shadow: none;
        }

        /* BUTTON PINK */
        .btn-pink {
            background: #ff4da6;
            color: white;
            border: none;
            border-radius: 12px;
            padding: 8px 18px;
            font-weight: 500;
        }

        .btn-pink:hover {
            background: #ff3385;
            color: white;
        }

        /* BUTTON KEMBALI */
        .btn-secondary {
            border-radius: 12px;
            padding: 8px 18px;
        }
    </style>

    <div class="form-box">

        <h2 class="title">Tambah Staf</h2>

        <form action="simpan_staf.php" method="POST">

            <div class="mb-3">
                <label>Username</label>
                <input type="text" name="username" class="form-control custom-input" required>
            </div>

            <div class="mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control custom-input" required>
            </div>

            <div class="mb-3">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control custom-input">
            </div>

            <div class="mb-3">
                <label>Role</label>
                <select name="role" class="form-control custom-input">
                    <option value="admin">Admin</option>
                    <option value="pemilik">Owner</option>
                    <option value="staf">Staf</option>
                </select>
            </div>

            <button type="submit" class="btn btn-pink">
                💾 Simpan
            </button>

            <a href="index.php?menu=staf" class="btn btn-secondary ms-2">
                Kembali
            </a>

        </form>

    </div>

</div>