<?php

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$nama = isset($_SESSION['nama']) ? $_SESSION['nama'] : "User";
?>

<!DOCTYPE html>
<html>

<head>
    <title>Dashboard Staf</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #fce4ec;
            /* soft pink */
        }

        /* NAVBAR PINK */
        .navbar {
            background: linear-gradient(90deg, #ff4da6, #ff66b2) !important;
        }

        .navbar .nav-link {
            color: white !important;
            font-weight: 500;
        }

        .navbar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 6px 12px;
        }

        /* CARD */
        .card-dashboard {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(255, 105, 180, 0.2);
            padding: 20px;
            transition: 0.3s;
            background: white;
        }

        .card-dashboard:hover {
            transform: translateY(-5px);
        }

        /* BUTTON LOGOUT JADI PUTIH */
        .btn-logout {
            background-color: white;
            color: #ff4da6;
            border: none;
            border-radius: 20px;
            padding: 6px 15px;
            font-weight: bold;
        }

        .btn-logout:hover {
            background-color: #ffe6f0;
            color: #ff4da6;
        }

        .footer-pink {
            background: linear-gradient(90deg, #ff4da6, #ff80bf);
            color: white;
            border-top-left-radius: 20px;
            border-top-right-radius: 20px;
        }

        /* Judul */
        .footer-pink h5 {
            font-weight: bold;
            margin-bottom: 15px;
        }

        /* Link */
        .footer-pink a {
            color: white;
            transition: 0.3s;
        }

        .footer-pink a:hover {
            color: #ffe6f0;
            padding-left: 5px;
        }

        /* List */
        .footer-pink ul li {
            margin-bottom: 8px;
        }

        /* Garis */
        .footer-pink hr {
            border-top: 1px solid rgba(255, 255, 255, 0.5);
        }

        /* Copyright */
        .footer-pink small {
            opacity: 0.9;
        }
    </style>

</head>

<body>

    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">

            <!-- BRAND (opsional biar sama kayak contoh) -->
            <a class="navbar-brand text-white fw-bold" href="#">Staff Panel</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">

                <ul class="navbar-nav me-auto">

                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Dashboard</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="index.php?menu=produk">Produk</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="index.php?menu=produk_masuk">Transaksi Barang Masuk</a>
                    </li>

                    <!-- DROPDOWN LAPORAN -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            Laporan
                        </a>

                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="?menu=laporan_pembelian">Laporan Pembelian</a></li>
                            <li><a class="dropdown-item" href="?menu=laporan_penjualan">Laporan Penjualan</a></li>
                            <li><a class="dropdown-item" href="?menu=laporan_produk">Laporan Produk</a></li>
                        </ul>
                    </li>

                </ul>

                <!-- HALO USER -->
                <span class="text-white me-3">
                    Halo, <b><?php echo $nama; ?></b>!
                </span>

                <a href="logout.php" class="btn btn-logout btn-sm">Logout</a>

            </div>
        </div>
    </nav>

    <!-- CONTENT -->
    <?php
    include "menu.php";
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <?php
    include "footer.php";
    ?>

</body>

</html>