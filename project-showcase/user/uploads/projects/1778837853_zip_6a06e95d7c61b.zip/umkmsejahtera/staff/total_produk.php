<?php
include "koneksi.php";

$query = mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk");
$data = mysqli_fetch_assoc($query);

$total_produk = $data['total'];

echo $total_produk;
?>