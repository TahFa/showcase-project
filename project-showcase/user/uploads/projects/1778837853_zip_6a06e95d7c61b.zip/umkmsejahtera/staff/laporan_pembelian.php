<?php
include "koneksi.php";
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Laporan Pembelian</title>

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" rel="stylesheet">
</head>
<style>
    /* Background halaman */
    body {
        background-color: #fff0f5;
    }

    /* Judul */
    h3 {
        color: #d63384;
        font-weight: bold;
    }

    /* Header tabel (gantikan hitam) */
    .table-dark {
        background-color: #ff69b4 !important;
        color: white;
    }

    .table-dark th {
        background-color: #ff69b4 !important;
        border-color: #ff69b4 !important;
    }

    /* Tombol primary jadi soft pink */
    .btn-primary {
        background-color: #ff85c1;
        border-color: #ff85c1;
    }

    .btn-primary:hover {
        background-color: #ff5fa8;
        border-color: #ff5fa8;
    }

    /* Tombol reset */
    .btn-secondary {
        background-color: #f8c8dc;
        border-color: #f8c8dc;
        color: #333;
    }

    .btn-secondary:hover {
        background-color: #f4a6c1;
        border-color: #f4a6c1;
    }

    /* Input focus */
    .form-control:focus {
        border-color: #ff85c1;
        box-shadow: 0 0 0 0.2rem rgba(255, 133, 193, 0.25);
    }

    /* Pagination DataTables */
    .page-item.active .page-link {
        background-color: #ff85c1;
        border-color: #ff85c1;
    }

    .page-link {
        color: #d63384;
    }

    .page-link:hover {
        color: #ff5fa8;
    }

    /* Table hover */
    .table-striped tbody tr:nth-of-type(odd) {
        background-color: #fff5f8;
    }
</style>

<body>

    <div class="container mt-4">
        <h3 class="mb-4">Laporan Pembelian (Produk Masuk)</h3>

        <!-- Filter tanggal -->
        <form method="GET" class="row g-3 mb-3">
            <input type="hidden" name="menu" value="laporan_pembelian">

            <div class="col-md-3">
                <input type="date" name="tgl_awal" class="form-control" value="<?= $_GET['tgl_awal'] ?? '' ?>">
            </div>
            <div class="col-md-3">
                <input type="date" name="tgl_akhir" class="form-control" value="<?= $_GET['tgl_akhir'] ?? '' ?>">
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">Filter</button>
                <a href="?menu=laporan_pembelian" class="btn btn-secondary">Reset</a>
            </div>
        </form>

        <table id="tabel" class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Nama Produk</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                    <th>Total</th>
                    <th>Staf</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;

                $where = "";
                if (!empty($_GET['tgl_awal']) && !empty($_GET['tgl_akhir'])) {
                    $tgl_awal = $_GET['tgl_awal'];
                    $tgl_akhir = $_GET['tgl_akhir'];
                    $where = "WHERE pm.tanggal BETWEEN '$tgl_awal' AND '$tgl_akhir'";
                }

                $query = mysqli_query($koneksi, "
            SELECT 
                pm.tanggal,
                p.nama_produk,
                d.jumlah,
                p.harga,
                (d.jumlah * p.harga) AS total,
                s.nama AS nama_staf
            FROM produk_masuk pm
            JOIN detail_produk_masuk d ON pm.id_masuk = d.id_masuk
            JOIN produk p ON d.id_produk = p.id_produk
            JOIN staf s ON pm.id_staf = s.id_staf
            $where
            ORDER BY pm.tanggal DESC
        ");

                while ($data = mysqli_fetch_assoc($query)) {
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $data['tanggal'] ?></td>
                        <td><?= $data['nama_produk'] ?></td>
                        <td><?= $data['jumlah'] ?></td>
                        <td>Rp <?= number_format($data['harga']) ?></td>
                        <td>Rp <?= number_format($data['total']) ?></td>
                        <td><?= $data['nama_staf'] ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- JS -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
     <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#tabel').DataTable();
        });
    </script>

</body>

</html>