<?php
include "koneksi.php";

/* Pastikan keranjang ada */
if (!isset($_SESSION['keranjang_masuk'])) {
    $_SESSION['keranjang_masuk'] = [];
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Transaksi Produk Masuk</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- CSS CUSTOM -->
    <style>
        body {
            background-color: #f8f9fa;
        }

        .card-custom {
            background: #fff;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
        }

        .title-custom {
            color: #e83e8c;
            font-weight: bold;
        }

        .btn-pink {
            background: #e83e8c;
            color: white;
            border-radius: 20px;
        }

        .btn-pink:hover {
            background: #d63384;
        }

        .form-control {
            border-radius: 15px;
        }

        .table thead {
            background: #e83e8c;
            color: white;
        }

        .table tbody tr:hover {
            background-color: #fce4ec;
        }

        .btn-success,
        .btn-secondary {
            border-radius: 20px;
        }

        .btn-danger {
            border-radius: 15px;
        }
    </style>
</head>

<body>

    <div class="container mt-4">

        <div class="card-custom">

            <h2 class="title-custom mb-4">Transaksi Produk Masuk</h2>

            <!-- FORM TAMBAH -->
            <form method="POST" action="tambah_keranjang_masuk.php">

                <div class="row mb-3">

                    <div class="col-md-5">
                        <select name="produk" class="form-control">
                            <?php
                            $data = mysqli_query($koneksi, "SELECT * FROM produk");
                            while ($d = mysqli_fetch_array($data)) {
                            ?>
                                <option value="<?php echo $d['id_produk']; ?>">
                                    <?php echo $d['nama_produk']; ?>
                                </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <input type="number" name="jumlah" class="form-control" placeholder="Jumlah" required>
                    </div>

                    <div class="col-md-2">
                        <button class="btn btn-pink w-100">+ Tambah</button>
                    </div>

                </div>

            </form>

            <hr>

            <!-- KERANJANG -->
            <h5>Keranjang</h5>

            <table class="table table-bordered text-center">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Produk</th>
                        <th>Jumlah</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php
                    $no = 1;

                    if (!empty($_SESSION['keranjang_masuk'])) {

                        foreach ($_SESSION['keranjang_masuk'] as $id_produk => $jumlah) {

                            $data = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk='$id_produk'");
                            $p = mysqli_fetch_assoc($data);

                            if ($p) {
                    ?>

                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><?php echo $p['nama_produk']; ?></td>
                                    <td><?php echo $jumlah; ?></td>

                                    <td>
                                        <a href="hapus_keranjang_masuk.php?id=<?php echo $id_produk; ?>"
                                            class="btn btn-danger btn-sm"
                                            onclick="return confirm('Yakin ingin menghapus?')">
                                            Hapus
                                        </a>
                                    </td>
                                </tr>

                        <?php
                            }
                        }
                    } else {
                        ?>

                        <tr>
                            <td colspan="4">Keranjang masih kosong</td>
                        </tr>

                    <?php } ?>

                </tbody>

            </table>

            <!-- BUTTON -->
            <div class="d-flex justify-content-between">
                <a href="?menu=index.pp" class="btn btn-secondary">Kembali</a>
                <a href="simpan_produk_masuk.php" class="btn btn-success">Simpan Transaksi</a>
            </div>

        </div>

    </div>
     <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>