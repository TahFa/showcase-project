<?php
session_start();

$id_produk = $_GET['id'];

unset($_SESSION['keranjang_masuk'][$id_produk]);

header("Location: index.php?menu=produk_masuk");
exit;
