<?php
session_start();

$id_produk = $_POST['produk'];
$jumlah = $_POST['jumlah'];

if (isset($_SESSION['keranjang_masuk'][$id_produk])) {

    $_SESSION['keranjang_masuk'][$id_produk] += $jumlah;
} else {

    $_SESSION['keranjang_masuk'][$id_produk] = $jumlah;
}

header("Location: index.php?menu=produk_masuk");
exit;
