<?php
session_start();
include "koneksi.php";

$username = $_POST['username'];
$password = md5($_POST['password']);
$captcha  = $_POST['captcha'];

if (strtolower($captcha) != strtolower($_SESSION['captcha'])) {
    echo "Captcha salah";
    exit;
}

$query = mysqli_query($koneksi, "SELECT * FROM staf WHERE username='$username' AND `password`='$password'");

if (mysqli_num_rows($query) > 0) {

    $data = mysqli_fetch_assoc($query);

    $_SESSION['id_staf'] = $data['id_staf'];
    $_SESSION['username'] = $data['username'];
    $_SESSION['nama'] = $data['nama'];
    $_SESSION['role'] = $data['role']; // ambil nama dari database

    header("Location: index.php");
    exit;
} else {
    echo "Username atau password salah";
}
