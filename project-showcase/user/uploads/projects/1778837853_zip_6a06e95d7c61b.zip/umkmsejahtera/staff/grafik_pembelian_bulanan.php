<?php
include "koneksi.php";

// Ambil data grafik
$query = mysqli_query($koneksi, "
    SELECT 
        MONTH(tanggal) AS bulan,
        SUM(d.jumlah * p.harga) AS total
    FROM produk_masuk pm
    JOIN detail_produk_masuk d ON pm.id_masuk = d.id_masuk
    JOIN produk p ON d.id_produk = p.id_produk
    GROUP BY MONTH(tanggal)
    ORDER BY MONTH(tanggal)
");

$bulan = [];
$total = [];

while ($data = mysqli_fetch_assoc($query)) {
    $bulan[] = $data['bulan'];
    $total[] = $data['total'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">
    <title>Grafik Pembelian</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        body {
            background-color: #f8f9fa;
        }

        .card-custom {
            background: #fff;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        }

        .title-custom {
            color: #e83e8c;
            font-weight: bold;
        }

        canvas {
            max-height: 400px;
        }
    </style>

</head>
<body>

<div class="container mt-5">

    <div class="card-custom">

        <h2 class="text-center title-custom mb-4">
            Grafik Pembelian Produk Bulanan
        </h2>

        <canvas id="grafik"></canvas>

    </div>

</div>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const canvas = document.getElementById('grafik');

    const bulan = <?= json_encode($bulan) ?>;
    const total = <?= json_encode($total) ?>;

    const namaBulan = bulan.map(b => {
        const list = ["Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des"];
        return list[b - 1];
    });

    new Chart(canvas, {
        type: 'bar',
        data: {
            labels: namaBulan,
            datasets: [{
                label: 'Total Pembelian (Rp)',
                data: total,
                backgroundColor: '#f7a8cd',
                borderRadius: 10
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    labels: {
                        color: '#333'
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

});
</script>

</body>
</html>