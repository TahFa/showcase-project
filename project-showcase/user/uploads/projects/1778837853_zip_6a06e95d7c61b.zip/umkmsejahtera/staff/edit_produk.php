<?php
include "koneksi.php";

$id = $_GET['id'];
$data = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk='$id'");
$d = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Produk</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #fff0f6;
        }

        .card-box {
            background: #fff;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(255, 105, 180, 0.2);
        }

        h3 {
            color: #d63384;
            font-weight: bold;
        }

        /* Input */
        .form-control {
            border-radius: 10px;
            border: 1px solid #ff99cc;
        }

        .form-control:focus {
            border-color: #ff4da6;
            box-shadow: 0 0 5px rgba(255, 77, 166, 0.5);
        }

        /* Button */
        .btn-pink {
            background: #ff4da6;
            color: white;
            border: none;
            border-radius: 10px;
            transition: 0.3s;
        }

        .btn-pink:hover {
            background: #e60073;
            transform: scale(1.05);
        }

        .btn-secondary {
            border-radius: 10px;
        }

        /* Gambar */
        .preview-img {
            border-radius: 10px;
            margin-top: 10px;
            transition: 0.3s;
        }

        .preview-img:hover {
            transform: scale(1.05);
        }
    </style>
</head>

<body>

    <div class="container mt-4">

        <div class="card-box">

            <h3>Edit Produk</h3>

            <form action="update_produk.php" method="POST" enctype="multipart/form-data">

                <input type="hidden" name="id_produk" value="<?php echo $d['id_produk']; ?>">

                <div class="mb-3">
                    <label class="form-label">Nama Produk</label>
                    <input type="text" name="nama_produk" class="form-control"
                        value="<?php echo $d['nama_produk']; ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Harga</label>
                    <input type="number" name="harga" class="form-control"
                        value="<?php echo $d['harga']; ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Stok</label>
                    <input type="number" name="stok" class="form-control"
                        value="<?php echo $d['stok']; ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Gambar Lama</label><br>
                    <img src="../admin/gambar/<?php echo $d['gambar']; ?>" width="120" class="preview-img">
                </div>

                <div class="mb-3">
                    <label class="form-label">Ganti Gambar</label>
                    <input type="file" name="gambar" class="form-control">
                </div>

                <button type="submit" class="btn btn-pink">
                    💾 Simpan
                </button>

                <a href="index.php?menu=produk" class="btn btn-secondary">
                    Kembali
                </a>

            </form>

        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>