<?php
session_start();
include "koneksi.php";

if (empty($_SESSION['keranjang_masuk'])) {
    echo "Keranjang kosong";
    exit;
}

/* ambil id staf dari session */
$id_staf = $_SESSION['id_staf'];

$tanggal = date("Y-m-d");

/* simpan transaksi */
mysqli_query($koneksi, "INSERT INTO produk_masuk (tanggal,id_staf)
VALUES ('$tanggal','$id_staf')");

/* ambil id transaksi */
$id_masuk = mysqli_insert_id($koneksi);

/* simpan detail produk */
foreach ($_SESSION['keranjang_masuk'] as $id_produk => $jumlah) {

    if ($id_produk != "" && $jumlah > 0) {

        mysqli_query($koneksi, "INSERT INTO detail_produk_masuk
        (id_masuk,id_produk,jumlah)
        VALUES
        ('$id_masuk','$id_produk','$jumlah')");

        mysqli_query($koneksi, "UPDATE produk
        SET stok = stok + $jumlah
        WHERE id_produk='$id_produk'");
    }
}

/* kosongkan keranjang */
unset($_SESSION['keranjang_masuk']);

header("Location: index.php?menu=produk_masuk");
exit;
